-- Boutique: categories, products, orders, order_items (SQLite)
CREATE TABLE IF NOT EXISTS product_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  categoryId INTEGER,
  description TEXT NOT NULL,
  price REAL NOT NULL,
  stock INTEGER NOT NULL DEFAULT 0,
  imageUrl TEXT,
  status TEXT NOT NULL DEFAULT 'published',
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(categoryId) REFERENCES product_categories(id)
);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  clientUserId INTEGER NOT NULL,
  total REAL NOT NULL,
  currency TEXT NOT NULL DEFAULT 'FCFA',
  status TEXT NOT NULL DEFAULT 'pending',
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(clientUserId) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  orderId INTEGER NOT NULL,
  productId INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  unitPrice REAL NOT NULL,
  total REAL NOT NULL,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(orderId) REFERENCES orders(id),
  FOREIGN KEY(productId) REFERENCES products(id)
);

INSERT OR IGNORE INTO product_categories (id, name, slug) VALUES
 (1, 'Matériel informatique', 'materiel-informatique'),
 (2, 'Services', 'services'),
 (3, 'Formations', 'formations');

INSERT OR IGNORE INTO products (id, title, slug, categoryId, description, price, stock, imageUrl, status) VALUES
 (1, 'Pack site vitrine', 'pack-site-vitrine', 2, 'Site vitrine rapide, optimisé SEO, livraison en 7 jours.', 180000, 50, '/uploads/products/site-vitrine.jpg', 'published'),
 (2, 'Audit infrastructure IT', 'audit-infrastructure-it', 2, 'Audit complet de votre SI avec plan d’actions.', 120000, 30, '/uploads/products/audit-it.jpg', 'published'),
 (3, 'Formation WordPress intensive', 'formation-wordpress', 3, '5 jours de formation pratique pour maîtriser WordPress.', 95000, 20, '/uploads/products/formation-wp.jpg', 'published');

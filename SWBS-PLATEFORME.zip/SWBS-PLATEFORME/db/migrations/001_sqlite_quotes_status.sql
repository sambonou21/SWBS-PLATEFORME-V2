-- SQLite: add status to quotes for tracking workflow
ALTER TABLE quotes ADD COLUMN status TEXT NOT NULL DEFAULT 'received';
UPDATE quotes SET status = 'received' WHERE status IS NULL;

-- Ajouter reference paiement Fedapay et role IA dans les messages (MySQL)
ALTER TABLE orders
  ADD COLUMN reference VARCHAR(100) NULL,
  ADD COLUMN paymentProvider VARCHAR(50) DEFAULT 'fedapay',
  ADD COLUMN paymentRef VARCHAR(100) NULL,
  ADD COLUMN paymentMode VARCHAR(20) DEFAULT 'sandbox';

UPDATE orders SET reference = IF(reference IS NULL, CONCAT('ORD-', id), reference);
CREATE UNIQUE INDEX idx_orders_reference ON orders(reference);

ALTER TABLE messages MODIFY senderRole ENUM('client','admin','guest','ai') NOT NULL;

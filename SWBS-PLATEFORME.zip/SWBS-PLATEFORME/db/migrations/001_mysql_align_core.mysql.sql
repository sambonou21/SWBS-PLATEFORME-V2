-- MySQL core alignment: email verification, lead conversations, quote status, nullable estimates
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS emailVerified TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS emailVerifyToken VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS emailVerifyExpires DATETIME NULL;

ALTER TABLE conversations
  MODIFY clientUserId INT UNSIGNED NULL,
  ADD COLUMN IF NOT EXISTS leadName VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS leadEmail VARCHAR(190) NULL,
  ADD COLUMN IF NOT EXISTS leadPhone VARCHAR(40) NULL,
  MODIFY status VARCHAR(30) NOT NULL DEFAULT 'open';

ALTER TABLE quotes
  MODIFY estimateMin INT UNSIGNED NULL,
  MODIFY estimateMax INT UNSIGNED NULL,
  ADD COLUMN IF NOT EXISTS status VARCHAR(30) NOT NULL DEFAULT 'received';

UPDATE quotes SET status = 'received' WHERE status IS NULL;

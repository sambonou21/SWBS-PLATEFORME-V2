-- Ajouter reference paiement Fedapay et role IA dans les messages (SQLite)
ALTER TABLE orders ADD COLUMN reference TEXT;
ALTER TABLE orders ADD COLUMN paymentProvider TEXT DEFAULT 'fedapay';
ALTER TABLE orders ADD COLUMN paymentRef TEXT;
ALTER TABLE orders ADD COLUMN paymentMode TEXT DEFAULT 'sandbox';
UPDATE orders SET reference = COALESCE(reference, 'ORD-' || id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_reference ON orders(reference);

PRAGMA foreign_keys = OFF;
CREATE TABLE IF NOT EXISTS messages_new (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  conversationId INTEGER NOT NULL,
  senderRole TEXT NOT NULL CHECK(senderRole IN ('client','admin','guest','ai')),
  senderUserId INTEGER,
  body TEXT NOT NULL,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  isRead INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY(conversationId) REFERENCES conversations(id)
);
INSERT INTO messages_new (id, conversationId, senderRole, senderUserId, body, createdAt, isRead)
  SELECT id, conversationId, senderRole, senderUserId, body, createdAt, isRead FROM messages;
DROP TABLE messages;
ALTER TABLE messages_new RENAME TO messages;
PRAGMA foreign_keys = ON;

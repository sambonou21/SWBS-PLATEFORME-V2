-- Boutique: categories, products, orders, order_items (MySQL)
CREATE TABLE IF NOT EXISTS product_categories (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(190) NOT NULL,
  slug VARCHAR(190) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_cat_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS products (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(200) NOT NULL,
  slug VARCHAR(190) NOT NULL,
  categoryId INT UNSIGNED NULL,
  description TEXT NOT NULL,
  price INT UNSIGNED NOT NULL,
  stock INT NOT NULL DEFAULT 0,
  imageUrl VARCHAR(255) NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'published',
  createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_prod_slug (slug),
  KEY idx_prod_cat (categoryId),
  CONSTRAINT fk_prod_cat FOREIGN KEY (categoryId) REFERENCES product_categories(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS orders (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  clientUserId INT UNSIGNED NOT NULL,
  total INT UNSIGNED NOT NULL,
  currency VARCHAR(10) NOT NULL DEFAULT 'FCFA',
  status VARCHAR(30) NOT NULL DEFAULT 'pending',
  createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_orders_client (clientUserId),
  CONSTRAINT fk_orders_client FOREIGN KEY (clientUserId) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS order_items (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  orderId INT UNSIGNED NOT NULL,
  productId INT UNSIGNED NOT NULL,
  quantity INT NOT NULL,
  unitPrice INT UNSIGNED NOT NULL,
  total INT UNSIGNED NOT NULL,
  createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_order_items_order (orderId),
  KEY idx_order_items_product (productId),
  CONSTRAINT fk_order_item_order FOREIGN KEY (orderId) REFERENCES orders(id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_order_item_product FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO product_categories (id, name, slug) VALUES
 (1, 'Matériel informatique', 'materiel-informatique'),
 (2, 'Services', 'services'),
 (3, 'Formations', 'formations');

INSERT IGNORE INTO products (id, title, slug, categoryId, description, price, stock, imageUrl, status) VALUES
 (1, 'Pack site vitrine', 'pack-site-vitrine', 2, 'Site vitrine rapide, optimisé SEO, livraison en 7 jours.', 180000, 50, '/uploads/products/site-vitrine.jpg', 'published'),
 (2, 'Audit infrastructure IT', 'audit-infrastructure-it', 2, 'Audit complet de votre SI avec plan d’actions.', 120000, 30, '/uploads/products/audit-it.jpg', 'published'),
 (3, 'Formation WordPress intensive', 'formation-wordpress', 3, '5 jours de formation pratique pour maîtriser WordPress.', 95000, 20, '/uploads/products/formation-wp.jpg', 'published');

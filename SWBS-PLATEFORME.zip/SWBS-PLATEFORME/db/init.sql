PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  role TEXT NOT NULL CHECK(role IN ('client','admin')),
  firstName TEXT NOT NULL,
  lastName TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  phone TEXT,
  passwordHash TEXT NOT NULL,
  isActive INTEGER NOT NULL DEFAULT 1,
  emailVerified INTEGER NOT NULL DEFAULT 0,
  emailVerifyToken TEXT,
  emailVerifyExpires DATETIME,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL,
  icon TEXT,
  imageUrl TEXT,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS portfolio (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  tagsJson TEXT,
  description TEXT NOT NULL,
  details TEXT,
  imageUrl TEXT,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS testimonials (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  rating INTEGER NOT NULL,
  text TEXT NOT NULL,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS quotes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  clientUserId INTEGER,
  payloadJson TEXT NOT NULL,
  estimateMin REAL,
  estimateMax REAL,
  status TEXT NOT NULL DEFAULT 'received',
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(clientUserId) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS conversations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  clientUserId INTEGER,
  leadName TEXT,
  leadEmail TEXT,
  leadPhone TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(clientUserId) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  conversationId INTEGER NOT NULL,
  senderRole TEXT NOT NULL CHECK(senderRole IN ('client','admin','guest','ai')),
  senderUserId INTEGER,
  body TEXT NOT NULL,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  isRead INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY(conversationId) REFERENCES conversations(id)
);

INSERT INTO services (title, category, description, icon, imageUrl) VALUES
 ('Cration de sites web', 'Web', 'Sites vitrines et e-commerce modernes, rapides et optimiss SEO pour les entreprises bninoises.', 'globe', '/assets/img/service-web.jpg'),
 ('Dveloppement logiciel sur mesure', 'Logiciel', 'Solutions mtiers personnalises pour automatiser vos processus et gagner en efficacit.', 'cogs', '/assets/img/service-software.jpg'),
 ('Applications mobiles', 'Mobile', 'Apps Android et iOS natives et hybrides adaptes au contexte local.', 'mobile-alt', '/assets/img/service-mobile.jpg'),
 ('Hbergement web', 'Hbergement', 'Packages Partag, VPS, Ddi, Cloud et WordPress avec surveillance 24/7.', 'server', '/assets/img/hosting.jpg'),
 ('Maintenance & support technique', 'Support', 'Supervision, mises  jour, scurit et assistance utilisateur au quotidien.', 'life-ring', '/assets/img/repair.jpg'),
 ('Rparation informatique', 'Rparation', 'Rparations dcran, clavier, connecteurs et composants avec pices garanties.', 'tools', '/assets/img/repair.jpg'),
 ('Marketing digital', 'Marketing', 'Campagnes social media, SEO, emailings et analytics orients conversion.', 'bullhorn', '/assets/img/portfolio-3.jpg'),
 ('Conseil en technologie', 'Conseil', 'Audit, architecture, choix technologiques et accompagnement stratgique.', 'lightbulb', '/assets/img/portfolio-4.jpg');

INSERT INTO portfolio (title, category, tagsJson, description, details, imageUrl) VALUES
 ('Plateforme e-commerce locale', 'Web', '["Web","Commerce"]', 'Boutique en ligne avec paiement mobile money et gestion de stocks.', 'Paiement mobile, catalogue dynamique, tableau de bord ventes.', '/assets/img/portfolio-1.jpg'),
 ('Application mobile de livraison', 'Mobile', '["Mobile","Logistique"]', 'Suivi temps rel des coursiers et notifications push clients.', 'Tracking GPS, chat livreur, planification tourne.', '/assets/img/portfolio-2.jpg'),
 ('Portail institutionnel', 'Web', '["Web","Institution"]', 'Site officiel avec accs presse et agenda public.', 'Publication CMS, cache, accessibilit AA.', '/assets/img/portfolio-3.jpg'),
 ('CRM pour PME', 'Logiciel', '["Logiciel","CRM"]', 'Gestion des leads, pipeline et relances automatises.', 'Reporting ventes, rles utilisateurs, import Excel.', '/assets/img/portfolio-4.jpg'),
 ('Dashboard nergie solaire', 'Web', '["Web","IoT"]', 'Suivi de production solaire et alertes SMS.', 'Graphiques temps rel, maintenance prventive.', '/assets/img/portfolio-5.jpg'),
 ('Refonte site dhbergement', 'Hbergement', '["Hbergement","Web"]', 'Offres VPS/Cloud avec commande en ligne scurise.', 'Intgration API facturation, monitoring uptime.', '/assets/img/portfolio-6.jpg'),
 ('Campagne marketing digital', 'Marketing', '["Marketing","Social"]', 'Social ads cibles et reporting de conversion.', 'Pixels de suivi, optimisation cra locale.', '/assets/img/portfolio-2.jpg'),
 ('Application de gestion de parc', 'Logiciel', '["Logiciel","Support"]', 'Inventaire matriel et tickets support intgrs.', 'Alertes SLA, exports, multi-entits.', '/assets/img/portfolio-1.jpg'),
 ('Mini ERP agro', 'Logiciel', '["Logiciel","Agro"]', 'Suivi des achats, stocks et ventes pour coopratives.', 'Multi-sites, traabilit lots, rles.', '/assets/img/portfolio-5.jpg'),
 ('Landing page vnementielle', 'Web', '["Web","Marketing"]', 'Page vnement avec formulaire et analytics.', 'Optimise mobile, tests A/B, animations lgres.', '/assets/img/portfolio-3.jpg');

INSERT INTO testimonials (name, rating, text) VALUES
 ('Acha A.', 5, 'SWBS nous a livr un site rapide et scuris, les clients commandent sans friction.'),
 ('Jean-Marc K.', 5, 'Equipe ractive, ils ont automatis notre reporting et rduit les erreurs de saisie.'),
 ('Prisca D.', 4, 'Le support est disponible, mme les week-ends, et les mises  jour sont transparentes.'),
 ('Rufin T.', 5, 'Notre application mobile est fluide, les notifications sont fiables pour nos livreurs.'),
 ('Mireille S.', 4, 'Bon accompagnement marketing, nos campagnes digitales ont doubl les leads.'),
 ('Fabrice H.', 5, 'La maintenance prventive a limin nos pannes critiques, bravo SWBS.'),
 ('Chancelle B.', 5, 'Conseils clairs, quipe pdagogue, on se sent accompagn au quotidien.'),
 ('Godwin L.', 4, 'Dploiement cloud bien matris, la supervision nous rassure.');

CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT OR IGNORE INTO app_settings (key, value) VALUES
  ('admin_presence', 'present'),
  ('currency_rates', '{"FCFA":1,"NGN":0,"USD":0,"EUR":0}');

CREATE TABLE IF NOT EXISTS product_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  categoryId INTEGER,
  description TEXT NOT NULL,
  price REAL NOT NULL,
  stock INTEGER NOT NULL DEFAULT 0,
  imageUrl TEXT,
  status TEXT NOT NULL DEFAULT 'published',
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(categoryId) REFERENCES product_categories(id)
);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  clientUserId INTEGER NOT NULL,
  total REAL NOT NULL,
  currency TEXT NOT NULL DEFAULT 'FCFA',
  status TEXT NOT NULL DEFAULT 'pending',
  reference TEXT UNIQUE,
  paymentProvider TEXT DEFAULT 'fedapay',
  paymentRef TEXT,
  paymentMode TEXT DEFAULT 'sandbox',
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(clientUserId) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  orderId INTEGER NOT NULL,
  productId INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  unitPrice REAL NOT NULL,
  total REAL NOT NULL,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(orderId) REFERENCES orders(id),
  FOREIGN KEY(productId) REFERENCES products(id)
);

INSERT OR IGNORE INTO product_categories (id, name, slug) VALUES
 (1, 'Matériel informatique', 'materiel-informatique'),
 (2, 'Services', 'services'),
 (3, 'Formations', 'formations');

INSERT OR IGNORE INTO products (id, title, slug, categoryId, description, price, stock, imageUrl, status) VALUES
 (1, 'Pack site vitrine', 'pack-site-vitrine', 2, 'Site vitrine rapide, optimisé SEO, livraison en 7 jours.', 180000, 50, '/uploads/products/site-vitrine.jpg', 'published'),
 (2, 'Audit infrastructure IT', 'audit-infrastructure-it', 2, 'Audit complet de votre SI avec plan d’actions.', 120000, 30, '/uploads/products/audit-it.jpg', 'published'),
 (3, 'Formation WordPress intensive', 'formation-wordpress', 3, '5 jours de formation pratique pour maîtriser WordPress.', 95000, 20, '/uploads/products/formation-wp.jpg', 'published');

require('dotenv').config();
const { bootstrap, ensureAdminFromEnv } = require('../lib/db');

(async () => {
  try {
    await bootstrap();
    await ensureAdminFromEnv();
    console.log('✅ Base de données initialisée (et admin vérifié).');
    process.exit(0);
  } catch (err) {
    console.error('❌ Erreur init-db:', err);
    process.exit(1);
  }
})();

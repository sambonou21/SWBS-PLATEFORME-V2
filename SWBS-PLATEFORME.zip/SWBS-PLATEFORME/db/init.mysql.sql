-- MySQL schema for SWBS Platform (utf8mb4)
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  role ENUM('client','admin') NOT NULL,
  firstName VARCHAR(100) NOT NULL,
  lastName VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL,
  phone VARCHAR(30) NULL,
  passwordHash VARCHAR(255) NOT NULL,
  emailVerified TINYINT(1) NOT NULL DEFAULT 0,
  emailVerifyToken VARCHAR(255) NULL,
  emailVerifyExpires DATETIME NULL,
  isActive TINYINT(1) NOT NULL DEFAULT 1,
  createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS services (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(200) NOT NULL,
  category VARCHAR(80) NOT NULL,
  description TEXT NOT NULL,
  icon VARCHAR(80) NULL,
  imageUrl VARCHAR(255) NULL,
  createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS portfolio (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(200) NOT NULL,
  category VARCHAR(80) NOT NULL,
  tagsJson TEXT NULL,
  description TEXT NOT NULL,
  details TEXT NULL,
  imageUrl VARCHAR(255) NULL,
  createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS testimonials (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  rating TINYINT UNSIGNED NOT NULL,
  text TEXT NOT NULL,
  createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS quotes (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  clientUserId INT UNSIGNED NULL,
  payloadJson TEXT NOT NULL,
  estimateMin INT UNSIGNED NULL,
  estimateMax INT UNSIGNED NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'received',
  createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_quotes_client (clientUserId),
  CONSTRAINT fk_quotes_client FOREIGN KEY (clientUserId) REFERENCES users(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS conversations (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  clientUserId INT UNSIGNED NULL,
  leadName VARCHAR(120) NULL,
  leadEmail VARCHAR(190) NULL,
  leadPhone VARCHAR(40) NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'open',
  createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_conv_client (clientUserId),
  CONSTRAINT fk_conv_client FOREIGN KEY (clientUserId) REFERENCES users(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS messages (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  conversationId INT UNSIGNED NOT NULL,
  senderRole ENUM('client','admin','guest','ai') NOT NULL,
  senderUserId INT UNSIGNED NULL,
  body TEXT NOT NULL,
  createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  isRead TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY idx_msg_conv (conversationId),
  KEY idx_msg_created (createdAt),
  CONSTRAINT fk_msg_conv FOREIGN KEY (conversationId) REFERENCES conversations(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- Seed (only if empty)
INSERT INTO services (title, category, description, icon, imageUrl)
SELECT * FROM (
  SELECT 'Création de sites web','Web','Sites vitrines, e-commerce, landing pages performantes, responsive et optimisées SEO.','globe','/assets/img/service-web.jpg' UNION ALL
  SELECT 'Développement logiciel sur mesure','Logiciel','Applications métier, automatisation, tableaux de bord et intégrations API adaptées à vos besoins.','cpu','/assets/img/service-software.jpg' UNION ALL
  SELECT 'Applications mobiles','Mobile','Applications Android/iOS, UI moderne, performance et notifications fiables.','smartphone','/assets/img/service-mobile.jpg' UNION ALL
  SELECT 'Hébergement web & cloud','Hébergement','Hébergement partagé, VPS, dédié, cloud et WordPress avec sécurité et supervision.','cloud','/assets/img/hosting.jpg' UNION ALL
  SELECT 'Maintenance & support','Support','Mises à jour, sauvegardes, surveillance, correction bugs et support réactif.','life-buoy','/assets/img/hosting.jpg' UNION ALL
  SELECT 'Réparation & dépannage','Réparation','Diagnostic, remplacement composants, réinstallation système, récupération données.','tool','/assets/img/repair.jpg' UNION ALL
  SELECT 'Marketing digital','Marketing','Campagnes, SEO, réseaux sociaux et stratégie de contenu orientée résultats.','megaphone','/assets/img/service-web.jpg' UNION ALL
  SELECT 'Conseil en technologie','Conseil','Audit, recommandations, architecture et choix techniques pour votre croissance.','briefcase','/assets/img/service-software.jpg'
) AS s
WHERE NOT EXISTS (SELECT 1 FROM services LIMIT 1);

INSERT INTO portfolio (title, category, tagsJson, description, details, imageUrl)
SELECT * FROM (
  SELECT 'Site corporate SWBS','Web','["Web","SEO","Landing"]','Conception d’un site corporate moderne et rapide.','Design, développement, optimisation performance et SEO.','/assets/img/portfolio-1.jpg' UNION ALL
  SELECT 'Boutique e-commerce','Web','["E-commerce","Paiement"]','Boutique en ligne avec paiement et gestion produits.','Catalogue, panier, paiement, emails transactionnels.','/assets/img/portfolio-2.jpg' UNION ALL
  SELECT 'App mobile livraison','Mobile','["Mobile","Notifications"]','Application mobile pour suivi des livraisons.','Suivi, notifications, profils et historique.','/assets/img/portfolio-3.jpg' UNION ALL
  SELECT 'Dashboard analytics','Logiciel','["SaaS","Dashboard"]','Tableau de bord de suivi activité et ventes.','KPIs, exports, rôles utilisateurs.','/assets/img/portfolio-4.jpg' UNION ALL
  SELECT 'Landing marketing','Marketing','["Ads","Conversion"]','Landing page optimisée conversion.','A/B tests, tracking, formulaires.','/assets/img/portfolio-5.jpg' UNION ALL
  SELECT 'Plateforme SaaS','Logiciel','["SaaS","Auth"]','Plateforme SaaS avec comptes et gestion clients.','Auth, rôles, paiements, admin.','/assets/img/portfolio-6.jpg'
) AS p
WHERE NOT EXISTS (SELECT 1 FROM portfolio LIMIT 1);

INSERT INTO testimonials (name, rating, text)
SELECT * FROM (
  SELECT 'Acha A.',5,'SWBS nous a livré un site rapide et sécurisé, les clients commandent sans friction.' UNION ALL
  SELECT 'Jean-Marc K.',5,'Équipe réactive : automatisation du reporting et réduction des erreurs.' UNION ALL
  SELECT 'Prisca D.',4,'Support disponible et mises à jour transparentes.' UNION ALL
  SELECT 'Rufin T.',5,'Application mobile fluide et notifications fiables.' UNION ALL
  SELECT 'Mireille S.',4,'Bon accompagnement marketing : nos leads ont augmenté.' UNION ALL
  SELECT 'Fabrice H.',5,'Maintenance préventive efficace, moins de pannes.' UNION ALL
  SELECT 'Chancelle B.',5,'Conseils clairs, équipe pédagogue.' UNION ALL
  SELECT 'Godwin L.',4,'Déploiement cloud bien maîtrisé et supervision rassurante.'
) AS t
WHERE NOT EXISTS (SELECT 1 FROM testimonials LIMIT 1);


CREATE TABLE IF NOT EXISTS app_settings (
  `key` VARCHAR(64) PRIMARY KEY,
  `value` TEXT NOT NULL,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT IGNORE INTO app_settings (`key`, `value`) VALUES
  ('admin_presence', 'present'),
  ('currency_rates', '{"FCFA":1,"NGN":0,"USD":0,"EUR":0}');

CREATE TABLE IF NOT EXISTS product_categories (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(190) NOT NULL,
  slug VARCHAR(190) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_cat_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS products (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(200) NOT NULL,
  slug VARCHAR(190) NOT NULL,
  categoryId INT UNSIGNED NULL,
  description TEXT NOT NULL,
  price INT UNSIGNED NOT NULL,
  stock INT NOT NULL DEFAULT 0,
  imageUrl VARCHAR(255) NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'published',
  createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_prod_slug (slug),
  KEY idx_prod_cat (categoryId),
  CONSTRAINT fk_prod_cat FOREIGN KEY (categoryId) REFERENCES product_categories(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS orders (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  clientUserId INT UNSIGNED NOT NULL,
  total INT UNSIGNED NOT NULL,
  currency VARCHAR(10) NOT NULL DEFAULT 'FCFA',
  status VARCHAR(30) NOT NULL DEFAULT 'pending',
  reference VARCHAR(100) UNIQUE,
  paymentProvider VARCHAR(50) DEFAULT 'fedapay',
  paymentRef VARCHAR(100),
  paymentMode VARCHAR(20) DEFAULT 'sandbox',
  createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_orders_client (clientUserId),
  UNIQUE KEY idx_orders_reference (reference),
  CONSTRAINT fk_orders_client FOREIGN KEY (clientUserId) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS order_items (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  orderId INT UNSIGNED NOT NULL,
  productId INT UNSIGNED NOT NULL,
  quantity INT NOT NULL,
  unitPrice INT UNSIGNED NOT NULL,
  total INT UNSIGNED NOT NULL,
  createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_order_items_order (orderId),
  KEY idx_order_items_product (productId),
  CONSTRAINT fk_order_item_order FOREIGN KEY (orderId) REFERENCES orders(id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_order_item_product FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO product_categories (id, name, slug) VALUES
 (1, 'Matériel informatique', 'materiel-informatique'),
 (2, 'Services', 'services'),
 (3, 'Formations', 'formations');

INSERT IGNORE INTO products (id, title, slug, categoryId, description, price, stock, imageUrl, status) VALUES
 (1, 'Pack site vitrine', 'pack-site-vitrine', 2, 'Site vitrine rapide, optimisé SEO, livraison en 7 jours.', 180000, 50, '/uploads/products/site-vitrine.jpg', 'published'),
 (2, 'Audit infrastructure IT', 'audit-infrastructure-it', 2, 'Audit complet de votre SI avec plan d’actions.', 120000, 30, '/uploads/products/audit-it.jpg', 'published'),
 (3, 'Formation WordPress intensive', 'formation-wordpress', 3, '5 jours de formation pratique pour maîtriser WordPress.', 95000, 20, '/uploads/products/formation-wp.jpg', 'published');

let CSRF_TOKEN = null;

async function getCsrfToken() {
  if (CSRF_TOKEN) return CSRF_TOKEN;
  const res = await fetch('/api/csrf', { credentials: 'include' });
  if (!res.ok) return null;
  const data = await res.json();
  CSRF_TOKEN = data.csrfToken;
  return CSRF_TOKEN;
}

let servicesCache = [];
let portfolioCache = [];
let testimonialsCache = [];
let productCache = [];

function setPreview(selector, url) {
  const preview = document.querySelector(selector);
  if (!preview) return;
  if (url) {
    preview.src = url;
    preview.style.display = 'block';
  } else {
    preview.style.display = 'none';
  }
}

function bindUpload(fileSelector, hiddenSelector, previewSelector) {
  const fileInput = document.querySelector(fileSelector);
  const hidden = document.querySelector(hiddenSelector);
  const preview = previewSelector ? document.querySelector(previewSelector) : null;
  if (!fileInput || !hidden) return;
  fileInput.addEventListener('change', async () => {
    if (!fileInput.files || !fileInput.files.length) return;
    const fd = new FormData();
    fd.append('file', fileInput.files[0]);
    const token = await getCsrfToken();
    const res = await fetch('/api/uploads', {
      method: 'POST',
      credentials: 'include',
      headers: token ? { 'X-CSRF-Token': token } : {},
      body: fd,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      alert(data.error || 'Upload impossible');
      fileInput.value = '';
      return;
    }
    hidden.value = data.url;
    if (preview) {
      preview.src = data.url;
      preview.style.display = 'block';
    }
  });
}

async function api(url, options = {}) {
  const method = (options.method || 'GET').toUpperCase();
  options.credentials = options.credentials || 'include';
  options.headers = options.headers || {};

  if (method !== 'GET' && method !== 'HEAD' && method !== 'OPTIONS') {
    const token = await getCsrfToken();
    if (token) options.headers['X-CSRF-Token'] = token;
  }

  const res = await fetch(url, options);
  if (res.status === 401 || res.status === 403) {
    window.location.href = '/admin/login';
    return null;
  }
  if (!res.ok) return null;
  return res.json();
}

document.addEventListener('DOMContentLoaded', () => {
  if (document.querySelector('#admin-stats')) loadStats();
  if (document.querySelector('#services-table')) initServices();
  if (document.querySelector('#portfolio-table')) initPortfolio();
  if (document.querySelector('#testimonials-table')) initTestimonials();
  if (document.querySelector('#clients-table')) loadClients();
  if (document.querySelector('#quotes-table')) loadQuotes();
  if (document.querySelector('#products-table')) initProducts();
  if (document.querySelector('#orders-table')) loadOrders();
  bindUpload('#service-image-file', '#service-image', '#service-image-preview');
  bindUpload('#portfolio-image-file', '#portfolio-image', '#portfolio-image-preview');
  bindUpload('#product-image-file', '#product-image', '#product-image-preview');
});

async function loadStats() {
  const result = await api('/api/admin/stats');
  if (!result) return;
  const { stats } = result;
  document.querySelector('#stat-clients')?.textContent = stats.clients;
  document.querySelector('#stat-conversations')?.textContent = stats.conversations;
  document.querySelector('#stat-messages')?.textContent = stats.messagesToday;
  document.querySelector('#stat-quotes')?.textContent = stats.quotes;
  document.querySelector('#stat-quotes-open')?.textContent = stats.quotesOpen ?? stats.quotes ?? 0;
  document.querySelector('#stat-orders')?.textContent = stats.orders ?? 0;

  document.querySelector('#badge-quotes')?.textContent = `Devis: ${stats.quotesOpen ?? stats.quotes ?? 0}`;
  document.querySelector('#badge-chat')?.textContent = `Chat: ${stats.conversations}`;
  document.querySelector('#badge-orders')?.textContent = `Cmd: ${stats.orders ?? 0}`;
}

// Services
function initServices() {
  const form = document.querySelector('#service-form');
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(form).entries());
    const method = body.id ? 'PUT' : 'POST';
    const url = '/api/services' + (body.id ? `/${body.id}` : '');
    const ok = await api(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (!ok) return;
    form.reset();
    document.querySelector('#service-image').value = '';
    setPreview('#service-image-preview', '');
    loadServices();
  });
  loadServices();
}

async function loadServices() {
  const table = document.querySelector('#services-table tbody');
  if (!table) return;
  const data = await api('/api/services');
  if (!data) return;
  servicesCache = data.services || [];
  table.innerHTML =
    servicesCache
      .map(
        (s) => `<tr>
        <td>${s.title}</td><td>${s.category}</td><td>${s.description}</td>
        <td><button data-edit="${s.id}">Editer</button> <button data-del="${s.id}">Supprimer</button></td>
      </tr>`
      )
      .join('') || '<tr><td colspan="4">Aucun service</td></tr>';

  table.querySelectorAll('[data-del]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      await api(`/api/services/${btn.dataset.del}`, { method: 'DELETE' });
      loadServices();
    })
  );
  table.querySelectorAll('[data-edit]').forEach((btn) =>
    btn.addEventListener('click', () => {
      const svc = servicesCache.find((s) => String(s.id) === btn.dataset.edit);
      if (!svc) return;
      document.querySelector('#service-id').value = svc.id;
      document.querySelector('#service-title').value = svc.title;
      document.querySelector('#service-category').value = svc.category;
      document.querySelector('#service-description').value = svc.description;
      document.querySelector('#service-image').value = svc.imageUrl || '';
      setPreview('#service-image-preview', svc.imageUrl || '');
    })
  );
}

// Portfolio
function initPortfolio() {
  const form = document.querySelector('#portfolio-form');
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(form).entries());
    const method = body.id ? 'PUT' : 'POST';
    const url = '/api/portfolio' + (body.id ? `/${body.id}` : '');
    const ok = await api(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (!ok) return;
    form.reset();
    document.querySelector('#portfolio-image').value = '';
    setPreview('#portfolio-image-preview', '');
    loadPortfolio();
  });
  loadPortfolio();
}

async function loadPortfolio() {
  const table = document.querySelector('#portfolio-table tbody');
  if (!table) return;
  const data = await api('/api/portfolio');
  if (!data) return;
  portfolioCache = data.portfolio || [];
  table.innerHTML =
    portfolioCache
      .map(
        (p) => `<tr>
        <td>${p.title}</td><td>${p.category}</td><td>${p.description}</td>
        <td><button data-edit="${p.id}">Editer</button> <button data-del="${p.id}">Supprimer</button></td>
      </tr>`
      )
      .join('') || '<tr><td colspan="4">Aucun projet</td></tr>';
  table.querySelectorAll('[data-del]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      await api(`/api/portfolio/${btn.dataset.del}`, { method: 'DELETE' });
      loadPortfolio();
    })
  );
  table.querySelectorAll('[data-edit]').forEach((btn) =>
    btn.addEventListener('click', () => {
      const p = portfolioCache.find((item) => String(item.id) === btn.dataset.edit);
      if (!p) return;
      document.querySelector('#portfolio-id').value = p.id;
      document.querySelector('#portfolio-title').value = p.title;
      document.querySelector('#portfolio-category').value = p.category;
      document.querySelector('#portfolio-tags').value = p.tagsJson || '[]';
      document.querySelector('#portfolio-description').value = p.description;
      document.querySelector('#portfolio-details').value = p.details || '';
      document.querySelector('#portfolio-image').value = p.imageUrl || '';
      setPreview('#portfolio-image-preview', p.imageUrl || '');
    })
  );
}

// Testimonials
function initTestimonials() {
  const form = document.querySelector('#testimonial-form');
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(form).entries());
    const method = body.id ? 'PUT' : 'POST';
    const url = '/api/testimonials' + (body.id ? `/${body.id}` : '');
    const ok = await api(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (!ok) return;
    form.reset();
    loadTestimonials();
  });
  loadTestimonials();
}

async function loadTestimonials() {
  const table = document.querySelector('#testimonials-table tbody');
  if (!table) return;
  const data = await api('/api/testimonials');
  if (!data) return;
  testimonialsCache = data.testimonials || [];
  table.innerHTML =
    testimonialsCache
      .map(
        (t) => `<tr>
        <td>${t.name}</td><td>${t.rating}</td><td>${t.text}</td>
        <td><button data-edit="${t.id}">Editer</button> <button data-del="${t.id}">Supprimer</button></td>
      </tr>`
      )
      .join('') || '<tr><td colspan="4">Aucun avis</td></tr>';
  table.querySelectorAll('[data-del]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      await api(`/api/testimonials/${btn.dataset.del}`, { method: 'DELETE' });
      loadTestimonials();
    })
  );
  table.querySelectorAll('[data-edit]').forEach((btn) =>
    btn.addEventListener('click', () => {
      const t = testimonialsCache.find((item) => String(item.id) === btn.dataset.edit);
      if (!t) return;
      document.querySelector('#testimonial-id').value = t.id;
      document.querySelector('#testimonial-name').value = t.name;
      document.querySelector('#testimonial-rating').value = t.rating;
      document.querySelector('#testimonial-text').value = t.text;
    })
  );
}

// Clients
async function loadClients() {
  const table = document.querySelector('#clients-table tbody');
  if (!table) return;
  const data = await api('/api/admin/clients');
  if (!data) return;
  table.innerHTML =
    data.clients
      .map(
        (c) => `<tr>
        <td>${c.firstName} ${c.lastName}</td><td>${c.email}</td><td>${c.phone}</td><td>${new Date(
          c.createdAt
        ).toLocaleDateString()}</td><td>${c.isActive ? 'Actif' : 'Inactif'}</td>
        <td><button data-toggle="${c.id}">${c.isActive ? 'Desactiver' : 'Activer'}</button></td>
      </tr>`
      )
      .join('') || '<tr><td colspan="6">Aucun client</td></tr>';
  table.querySelectorAll('[data-toggle]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      const id = btn.dataset.toggle;
      const newStatus = btn.textContent.includes('Desactiver') ? 0 : 1;
      await api(`/api/admin/clients/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: newStatus }),
      });
      loadClients();
    })
  );
}

// Quotes
async function loadQuotes() {
  const table = document.querySelector('#quotes-table tbody');
  if (!table) return;
  const data = await api('/api/admin/quotes');
  if (!data) return;
  table.innerHTML = (data.quotes || [])
    .map((q) => {
      const payload = JSON.parse(q.payloadJson || '{}');
      return `<tr>
        <td>${q.id}</td>
        <td>${payload.type || 'N/A'}</td>
        <td>${q.firstName || ''} ${q.lastName || ''}</td>
        <td>${q.estimateMin || '-'} - ${q.estimateMax || '-'} FCFA</td>
        <td>
          <select data-status="${q.id}">
            <option value="received" ${q.status === 'received' ? 'selected' : ''}>Recu</option>
            <option value="in_progress" ${q.status === 'in_progress' ? 'selected' : ''}>En cours</option>
            <option value="approved" ${q.status === 'approved' ? 'selected' : ''}>Valide</option>
            <option value="rejected" ${q.status === 'rejected' ? 'selected' : ''}>Refuse</option>
          </select>
        </td>
        <td>${new Date(q.createdAt).toLocaleString()}</td>
        <td><a class="btn secondary" target="_blank" href="https://wa.me/22996368877?text=${encodeURIComponent(
          'Reponse devis #' + q.id
        )}">Repondre WhatsApp</a></td>
      </tr>`;
    })
    .join('');

  table.querySelectorAll('select[data-status]').forEach((sel) =>
    sel.addEventListener('change', async () => {
      const id = sel.getAttribute('data-status');
      const status = sel.value;
      await api(`/api/admin/quotes/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
    })
  );
}

// Products
function initProducts() {
  const form = document.querySelector('#product-form');
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(form).entries());
    body.price = Number(body.price || 0);
    body.stock = Number(body.stock || 0);
    const method = body.id ? 'PUT' : 'POST';
    const url = '/api/products/admin' + (body.id ? `/${body.id}` : '');
    const ok = await api(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!ok) return;
    form.reset();
    document.querySelector('#product-image').value = '';
    setPreview('#product-image-preview', '');
    loadProducts();
  });
  loadProducts();
}

async function loadProducts() {
  const table = document.querySelector('#products-table tbody');
  if (!table) return;
  const data = await api('/api/products/admin/list/all');
  if (!data) return;
  productCache = data.products || [];
  table.innerHTML =
    productCache
      .map(
        (p) => `<tr>
        <td>${p.title}</td><td>${p.price} FCFA</td><td>${p.stock}</td><td>${p.status}</td>
        <td><button data-edit="${p.id}">Editer</button> <button data-del="${p.id}">Supprimer</button></td>
      </tr>`
      )
      .join('') || '<tr><td colspan="5">Aucun produit</td></tr>';
  table.querySelectorAll('[data-del]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      await api(`/api/products/admin/${btn.dataset.del}`, { method: 'DELETE' });
      loadProducts();
    })
  );
  table.querySelectorAll('[data-edit]').forEach((btn) =>
    btn.addEventListener('click', () => {
      const p = productCache.find((item) => String(item.id) === btn.dataset.edit);
      if (!p) return;
      document.querySelector('#product-id').value = p.id;
      document.querySelector('#product-title').value = p.title;
      document.querySelector('#product-slug').value = p.slug;
      document.querySelector('#product-category').value = p.categoryId || '';
      document.querySelector('#product-description').value = p.description;
      document.querySelector('#product-price').value = p.price;
      document.querySelector('#product-stock').value = p.stock;
      document.querySelector('#product-status').value = p.status;
      document.querySelector('#product-image').value = p.imageUrl || '';
      setPreview('#product-image-preview', p.imageUrl || '');
    })
  );
}

// Orders
async function loadOrders() {
  const table = document.querySelector('#orders-table tbody');
  if (!table) return;
  const data = await api('/api/orders/admin');
  if (!data) return;
  const orders = data.orders || [];
  table.innerHTML =
    orders
      .map(
        (o) => `<tr>
        <td>${o.id}</td>
        <td>${o.firstName || ''} ${o.lastName || ''}</td>
        <td>${o.total}</td>
        <td>${o.currency}</td>
        <td>
          <select data-order-status="${o.id}">
            <option value="pending" ${o.status === 'pending' ? 'selected' : ''}>Pending</option>
            <option value="paid" ${o.status === 'paid' ? 'selected' : ''}>Paid</option>
            <option value="canceled" ${o.status === 'canceled' ? 'selected' : ''}>Canceled</option>
            <option value="delivered" ${o.status === 'delivered' ? 'selected' : ''}>Delivered</option>
          </select>
        </td>
        <td>${new Date(o.createdAt).toLocaleString()}</td>
        <td><button data-items="${o.id}">Voir</button></td>
      </tr>`
      )
      .join('') || '<tr><td colspan="7">Aucune commande</td></tr>';

  table.querySelectorAll('select[data-order-status]').forEach((sel) =>
    sel.addEventListener('change', async () => {
      const id = sel.getAttribute('data-order-status');
      const status = sel.value;
      await api(`/api/orders/admin/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
    })
  );

  table.querySelectorAll('button[data-items]').forEach((btn) =>
    btn.addEventListener('click', () => loadOrderItems(btn.getAttribute('data-items')))
  );
}

async function loadOrderItems(orderId) {
  const card = document.querySelector('#order-items-card');
  const box = document.querySelector('#order-items');
  if (!card || !box) return;
  const data = await api(`/api/orders/admin/${orderId}/items`);
  if (!data) return;
  card.style.display = 'block';
  box.innerHTML =
    data.items
      .map(
        (it) => `<div class="row" style="justify-content:space-between;">
        <span>${it.title}</span>
        <span>${it.quantity} x ${it.unitPrice} = ${it.total}</span>
      </div>`
      )
      .join('') || '<div class="muted">Aucun article</div>';
}

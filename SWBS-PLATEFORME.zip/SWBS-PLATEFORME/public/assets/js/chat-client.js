let socket;

// If embedded (chat widget), tighten spacing and hide big title
try {
  const params = new URLSearchParams(window.location.search);
  if (params.get('embed') === '1') {
    document.documentElement.classList.add('chat-embed');
  }
} catch {}

document.addEventListener('DOMContentLoaded', () => {
  const messagesEl = document.querySelector('#messages');
  const form = document.querySelector('#chat-form');
  const input = document.querySelector('#chat-input');
  const typingEl = document.querySelector('#typing');
  const statusEl = document.querySelector('#admin-status');
  const badgeEl = document.querySelector('#badge');
  const sendStatus = document.querySelector('#send-status');

  if (!messagesEl || !form) return;

  let conversationId;

  const append = (msg, mine) => {
    const div = document.createElement('div');
    div.className = `bubble ${mine ? 'me' : 'them'}`;
    div.innerHTML = `<small>${new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small><br>${msg.body}`;
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  };

  const loadMessages = async () => {
    const res = await fetch(`/api/chat/messages/${conversationId}`, { credentials: 'include' });
    if (!res.ok) return;
    const data = await res.json();
    messagesEl.innerHTML = '';
    data.messages.forEach((m) => append(m, m.senderRole === 'client'));
  };

  const ensureConversation = async () => {
    const csrf = await getCsrfToken();
    let res = await fetch('/api/chat/start', {
      method: 'POST',
      headers: csrf ? { 'X-CSRF-Token': csrf } : {},
      credentials: 'include',
    });
    if (res.status === 401) {
      // Try guest session
      res = await fetch('/api/chat/guest-conversation', { credentials: 'include' });
    }
    if (res.status === 401) {
      const guestBox = document.querySelector('#guest-form');
      const guestForm = document.querySelector('#guest-start');
      if (guestBox) guestBox.style.display = 'block';
      if (statusEl) statusEl.textContent = 'Veuillez renseigner vos informations pour demarrer le chat.';
      if (guestForm) {
        guestForm.addEventListener(
          'submit',
          async (e) => {
            e.preventDefault();
            const fd = new FormData(guestForm);
            const payload = { name: fd.get('name'), email: fd.get('email'), phone: fd.get('phone') };
            const csrfGuest = await getCsrfToken();
            const r = await fetch('/api/chat/guest-start', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                ...(csrfGuest ? { 'X-CSRF-Token': csrfGuest } : {}),
              },
              body: JSON.stringify(payload),
              credentials: 'include',
            });
            const d = await r.json().catch(() => ({}));
            if (!r.ok) {
              alert(d.error || 'Impossible de demarrer le chat');
              return;
            }
            if (guestBox) guestBox.style.display = 'none';
            window.location.reload();
          },
          { once: true }
        );
      }
      return;
    }
    if (!res.ok) {
      console.error('Chat start failed', await res.text());
      if (statusEl) statusEl.textContent = 'Impossible de demarrer le chat. Rechargez la page.';
      return;
    }
    const data = await res.json();
    conversationId = data.conversationId;
    await loadMessages();
    initSocket();
  };

  const initSocket = () => {
    socket = io({ transports: ['websocket', 'polling'], withCredentials: true });
    socket.on('connect', () => {
      socket.emit('chat:join', { conversationId });
    });
    socket.on('chat:message', ({ message }) => {
      if (message.conversationId !== conversationId) return;
      append(message, message.senderRole === 'client');
      badgeEl && (badgeEl.textContent = '');
      sendStatus && (sendStatus.textContent = '');
    });
    socket.on('chat:typing', ({ isTyping, from }) => {
      typingEl.textContent = isTyping && from === 'admin' ? 'L admin ecrit...' : '';
    });
    socket.on('chat:read', () => {
      // could update UI if needed
    });
    socket.on('admin:online', ({ online }) => {
      if (statusEl) {
        statusEl.textContent = online ? 'Admin en ligne' : 'Admin hors ligne - Nous repondons rapidement';
        statusEl.className = online ? 'tag pill-success' : 'tag pill-warning';
      }
    });
  };

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!input.value.trim()) return;
    const body = input.value.trim();
    sendStatus && (sendStatus.textContent = 'Envoi...');
    socket.emit('chat:message', { conversationId, body }, (resp) => {
      if (resp?.ok) {
        sendStatus && (sendStatus.textContent = 'Message envoye');
        setTimeout(() => sendStatus && (sendStatus.textContent = ''), 1200);
      } else {
        sendStatus && (sendStatus.textContent = 'Erreur envoi');
      }
    });
    input.value = '';
  });

  input.addEventListener('input', () => {
    socket?.emit('chat:typing', { conversationId, isTyping: input.value.length > 0 });
  });

  ensureConversation();
});

async function getCsrfToken() {
  try {
    const res = await fetch('/api/csrf', { credentials: 'include' });
    if (!res.ok) return null;
    const data = await res.json();
    return data.csrfToken;
  } catch {
    return null;
  }
}

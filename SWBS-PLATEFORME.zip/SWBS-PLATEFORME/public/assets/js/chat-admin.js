let socket;
let conversations = [];
let activeId = null;
const joinedConvoIds = new Set();
let beep;

document.addEventListener('DOMContentLoaded', () => {
  beep = new Audio('data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAESsAACJWAAACABAAZGF0YQAAAAA=');
  loadConversations().then(() => initSocket());

  document.querySelector('#admin-chat-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const input = document.querySelector('#admin-chat-input');
    if (!input.value.trim() || !activeId) return;
    socket.emit('chat:message', { conversationId: activeId, body: input.value.trim() });
    input.value = '';
  });
});

async function loadConversations() {
  const list = document.querySelector('#admin-conversations');
  if (!list) return;
  const res = await fetch('/api/admin/conversations');
  if (res.status === 401 || res.status === 403) {
    window.location.href = '/admin/login';
    return;
  }
  if (!res.ok) return;
  const data = await res.json();
  conversations = data.conversations || [];
  // Join rooms for any new conversations (prevents missing messages)
  if (socket && socket.connected) {
    conversations.forEach((c) => {
      const id = String(c.id);
      if (joinedConvoIds.has(id)) return;
      socket.emit('chat:join', { conversationId: c.id });
      joinedConvoIds.add(id);
    });
  }
  list.innerHTML = conversations
    .map(
      (c) => `<div class="conversation" data-id="${c.id}">
        <div class="flex"><strong>${c.firstName} ${c.lastName}</strong><span class="tag">${c.status}</span></div>
        <small>${c.email}</small>
        <div class="tag">${c.unreadClient} nouveaux</div>
      </div>`
    )
    .join('');

  list.querySelectorAll('.conversation').forEach((el) =>
    el.addEventListener('click', () => {
      activeId = Number(el.dataset.id);
      document.querySelectorAll('.conversation').forEach((c) => c.classList.toggle('active', c === el));
      loadMessages(activeId);
    })
  );

  if (!activeId && conversations[0]) {
    activeId = conversations[0].id;
    loadMessages(activeId);
  }
}

async function loadMessages(id) {
  const res = await fetch(`/api/chat/messages/${id}`, { credentials: 'include' });
  if (!res.ok) return;
  const data = await res.json();
  const box = document.querySelector('#admin-messages');
  box.innerHTML = data.messages
    .map(
      (m) => `<div class="bubble ${m.senderRole === 'admin' || m.senderRole === 'ai' ? 'me' : 'client'}">
        <small>${new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small><br>${m.body}
      </div>`
    )
    .join('');
  box.scrollTop = box.scrollHeight;
  socket?.emit('chat:read', { conversationId: id });
  // reset unread count for active conversation
  const convo = conversations.find((c) => c.id === id);
  if (convo) convo.unreadClient = 0;
}

function initSocket() {
  socket = io({ transports: ['websocket', 'polling'], withCredentials: true });
  socket.on('connect', () => {
    conversations.forEach((c) => {
      socket.emit('chat:join', { conversationId: c.id });
      joinedConvoIds.add(String(c.id));
    });
  });
  socket.on('chat:message', ({ message }) => {
    const convo = conversations.find((c) => c.id === message.conversationId);
    if (convo) convo.unreadClient = (convo.unreadClient || 0) + (message.senderRole === 'client' ? 1 : 0);
    if (message.conversationId === activeId) {
      loadMessages(activeId);
      socket.emit('chat:read', { conversationId: activeId });
    } else {
      showToast('Nouveau message client');
      beep?.play().catch(() => {});
      if (Notification.permission === 'granted') {
        new Notification('Nouveau message SWBS', { body: message.body });
      } else if (Notification.permission === 'default') {
        Notification.requestPermission();
      }
    }
    loadConversations();
  });
}

function showToast(text) {
  const toast = document.querySelector('.toast');
  if (!toast) return;
  toast.textContent = text;
  toast.style.display = 'block';
  setTimeout(() => (toast.style.display = 'none'), 3500);
}

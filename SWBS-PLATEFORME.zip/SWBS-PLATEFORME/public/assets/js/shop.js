(() => {
  const CART_KEY = 'swbs_cart';

  document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('#products-list')) loadProducts();
    if (document.querySelector('#product-detail')) loadProductDetail();
    renderCart();
    document.querySelector('#checkout')?.addEventListener('click', checkout);
  });

  function getCart() {
    try {
      return JSON.parse(localStorage.getItem(CART_KEY) || '[]');
    } catch {
      return [];
    }
  }

  function saveCart(items) {
    localStorage.setItem(CART_KEY, JSON.stringify(items));
    renderCart();
  }

  function addToCart(product, qty = 1) {
    const cart = getCart();
    const existing = cart.find((c) => c.productId === product.id);
    if (existing) {
      existing.quantity += qty;
    } else {
      cart.push({
        productId: product.id,
        title: product.title,
        price: product.price,
        slug: product.slug,
        quantity: qty,
      });
    }
    saveCart(cart);
  }

  async function loadProducts() {
    const list = document.querySelector('#products-list');
    if (!list) return;
    const res = await fetch('/api/products');
    if (!res.ok) return;
    const data = await res.json();
    list.innerHTML = data.products
      .map(
        (p) => `<div class="card">
          <div class="service-icon" aria-hidden="true">*</div>
          <h3>${p.title}</h3>
          <p>${p.description}</p>
          <div class="chips"><span class="chip">${p.categoryName || ''}</span></div>
          <div class="price" data-amount="${p.price}">${p.price} FCFA</div>
          <div class="flex">
            <a class="btn ghost" href="/boutique/${p.slug}">Voir</a>
            <button class="btn" data-add="${p.id}">Ajouter</button>
          </div>
        </div>`
      )
      .join('');
    list.querySelectorAll('[data-add]').forEach((btn) => {
      const product = data.products.find((p) => String(p.id) === String(btn.dataset.add));
      btn.addEventListener('click', () => {
        if (product) addToCart(product, 1);
      });
    });
    if (window.swbsRenderPrices) window.swbsRenderPrices();
  }

  async function loadProductDetail() {
    const box = document.querySelector('#product-detail');
    if (!box) return;
    const slug = window.location.pathname.split('/').pop();
    const res = await fetch(`/api/products/${slug}`);
    if (!res.ok) {
      box.innerHTML = '<p>Produit introuvable.</p>';
      return;
    }
    const { product } = await res.json();
    const image = product.imageUrl ? `<img src="${product.imageUrl}" alt="${product.title}" class="product-cover">` : '';
    box.innerHTML = `
      ${image}
      <h2>${product.title}</h2>
      <p>${product.description}</p>
      <div class="chips"><span class="chip">${product.categoryName || ''}</span></div>
      <div class="price" data-amount="${product.price}">${product.price} FCFA</div>
      <div class="flex" style="margin-top:10px;">
        <button class="btn" id="add-detail">Ajouter au panier</button>
        <a class="btn ghost" href="/boutique">Retour</a>
      </div>
    `;
    document.querySelector('#add-detail')?.addEventListener('click', () => addToCart(product, 1));
    if (window.swbsRenderPrices) window.swbsRenderPrices();
  }

  function renderCart() {
    const itemsEl = document.querySelector('#cart-items');
    const totalEl = document.querySelector('#cart-total');
    if (!itemsEl || !totalEl) return;
    const cart = getCart();
    if (!cart.length) {
      itemsEl.innerHTML = '<p class="muted">Panier vide.</p>';
      totalEl.textContent = '';
      return;
    }

    let totalAmount = 0;
    itemsEl.innerHTML = cart
      .map((it) => {
        const lineTotal = (Number(it.price) || 0) * (Number(it.quantity) || 1);
        totalAmount += lineTotal;
        const display = window.swbsFormatMoney ? window.swbsFormatMoney(lineTotal) : `${lineTotal} FCFA`;
        return `<div class="row" style="justify-content:space-between;align-items:center;">
          <div>
            <div class="bold">${it.title || 'Produit #' + it.productId}</div>
            <small>${window.swbsFormatMoney ? window.swbsFormatMoney(it.price) : `${it.price} FCFA`}</small>
          </div>
          <div class="flex" style="gap:6px;align-items:center;">
            <input type="number" min="1" value="${it.quantity}" data-qty="${it.productId}" style="width:70px;">
            <span class="tag">${display}</span>
            <button class="btn ghost" data-remove="${it.productId}">Supprimer</button>
          </div>
        </div>`;
      })
      .join('');

    const totalDisplay = window.swbsFormatMoney ? window.swbsFormatMoney(totalAmount) : `${totalAmount} FCFA`;
    totalEl.textContent = `Total: ${totalDisplay}`;

    itemsEl.querySelectorAll('input[data-qty]').forEach((inp) =>
      inp.addEventListener('change', () => {
        const pid = Number(inp.getAttribute('data-qty'));
        const cartItems = getCart();
        const found = cartItems.find((x) => x.productId === pid);
        if (found) {
          found.quantity = Math.max(1, Number(inp.value || 1));
          saveCart(cartItems);
        }
      })
    );
    itemsEl.querySelectorAll('button[data-remove]').forEach((btn) =>
      btn.addEventListener('click', () => {
        const pid = Number(btn.getAttribute('data-remove'));
        saveCart(getCart().filter((c) => c.productId !== pid));
      })
    );
  }

  async function checkout() {
    const cart = getCart();
    if (!cart.length) {
      alert('Panier vide');
      return;
    }
    const me = await fetch('/api/me', { credentials: 'include' });
    if (me.status === 401) {
      window.location.href = `/login?next=${encodeURIComponent('/boutique')}`;
      return;
    }
    const currency = localStorage.getItem('swbs_currency') || 'FCFA';
    const payloadItems = cart.map((c) => ({ productId: c.productId, quantity: c.quantity }));
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ items: payloadItems, currency }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      alert(data.error || 'Commande impossible');
      return;
    }

    try {
      const pay = await fetch('/api/payments/fedapay/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ orderId: data.orderId }),
      });
      const payData = await pay.json().catch(() => ({}));
      if (pay.ok && payData.checkoutUrl) {
        localStorage.removeItem(CART_KEY);
        renderCart();
        window.location.href = payData.checkoutUrl;
        return;
      }
    } catch (e) {
      console.error('Fedapay init failed', e);
    }

    localStorage.removeItem(CART_KEY);
    renderCart();
    alert('Commande enregistree. Suivi dans votre dashboard.');
    window.location.href = '/dashboard';
  }
})();

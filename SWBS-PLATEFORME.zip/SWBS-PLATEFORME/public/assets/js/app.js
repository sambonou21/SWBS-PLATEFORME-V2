(() => {
  const prefersDark =
    localStorage.getItem('theme') ||
    (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  const applyTheme = (theme) => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  };
  applyTheme(prefersDark);

  window.swbsRates = { FCFA: 1, NGN: 0, USD: 0, EUR: 0 };

  document.addEventListener('DOMContentLoaded', () => {
    const themeToggle = document.querySelector('.theme-toggle');
    if (themeToggle) {
      themeToggle.addEventListener('click', () => {
        const current = document.documentElement.getAttribute('data-theme') || 'dark';
        applyTheme(current === 'dark' ? 'light' : 'dark');
      });
    }
    // Lang switch
    document.querySelectorAll('[data-lang]').forEach((btn) =>
      btn.addEventListener('click', () => {
        if (window.swbsSetLang) window.swbsSetLang(btn.getAttribute('data-lang'));
      })
    );

    const burger = document.querySelector('.burger');
    const burgerMenu = document.querySelector('.burger-menu');
    if (burger && burgerMenu) {
      const closeMenu = () => {
        burgerMenu.classList.remove('open');
        burger.setAttribute('aria-expanded', 'false');
      };
      const openMenu = () => {
        burgerMenu.classList.add('open');
        burger.setAttribute('aria-expanded', 'true');
      };
      const toggleMenu = () => {
        const isOpen = burgerMenu.classList.contains('open');
        if (isOpen) closeMenu();
        else openMenu();
      };

      burger.setAttribute('aria-controls', 'burger-menu');
      burger.setAttribute('aria-expanded', burgerMenu.classList.contains('open') ? 'true' : 'false');
      burgerMenu.id = burgerMenu.id || 'burger-menu';

      burger.addEventListener('click', (e) => {
        e.preventDefault();
        toggleMenu();
      });

      burgerMenu.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => closeMenu()));

      document.addEventListener('click', (e) => {
        if (!burgerMenu.classList.contains('open')) return;
        if (burger.contains(e.target) || burgerMenu.contains(e.target)) return;
        closeMenu();
      });

      window.addEventListener('resize', () => {
        if (window.innerWidth >= 900) closeMenu();
      });
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeMenu();
      });
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.style.opacity = 1;
            entry.target.style.transform = 'translateY(0px)';
          }
        });
      },
      { threshold: 0.2 }
    );

    document.querySelectorAll('[data-animate]').forEach((el) => {
      el.style.opacity = 0;
      el.style.transform = 'translateY(20px)';
      observer.observe(el);
    });

    initCurrencySwitch();
    fetchRates();
    loadServices();
    loadTestimonials();
    initChatWidget();
  });

  async function fetchRates() {
    try {
      const res = await fetch('/api/public/currency');
      if (!res.ok) return;
      const data = await res.json();
      if (data.rates) {
        window.swbsRates = data.rates;
        renderPrices();
      }
    } catch {}
  }

  function initChatWidget() {
    if (window.location.pathname.startsWith('/admin/')) return;

    const existing = document.querySelector('#swbs-chat-widget');
    if (existing) return;

    const btn = document.createElement('button');
    btn.id = 'swbs-chat-fab';
    btn.setAttribute('aria-label', 'Ouvrir le chat SWBS');
    btn.innerHTML = 'Chat';

    const panel = document.createElement('div');
    panel.id = 'swbs-chat-widget';
    panel.innerHTML = `
      <div class="swbs-chat-head">
        <div>
          <strong>Chat SWBS</strong>
          <div class="swbs-chat-sub">Support en direct</div>
        </div>
        <button class="swbs-chat-close" aria-label="Fermer">x</button>
      </div>
      <iframe title="Chat SWBS" src="/chat?embed=1" class="swbs-chat-frame"></iframe>
    `;

    document.body.appendChild(btn);
    document.body.appendChild(panel);

    const open = () => panel.classList.add('open');
    const close = () => panel.classList.remove('open');

    btn.addEventListener('click', () => {
      panel.classList.contains('open') ? close() : open();
    });
    panel.querySelector('.swbs-chat-close')?.addEventListener('click', close);

    document.querySelectorAll('a[href="/chat"], a[href="/chat?"]').forEach((a) => {
      a.addEventListener('click', (e) => {
        e.preventDefault();
        open();
      });
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') close();
    });
  }

  function initCurrencySwitch() {
    const SWBS_CURRENCIES = {
      FCFA: { code: 'XOF', symbol: 'FCFA' },
      NGN: { code: 'NGN', symbol: 'NGN' },
      USD: { code: 'USD', symbol: 'USD' },
      EUR: { code: 'EUR', symbol: 'EUR' },
    };

    const getCurrency = () => localStorage.getItem('swbs_currency') || 'FCFA';
    const setCurrency = (c) => localStorage.setItem('swbs_currency', c);

    window.swbsFormatMoney = function swbsFormatMoney(amount, currencyKey = getCurrency()) {
      const cur = SWBS_CURRENCIES[currencyKey] || SWBS_CURRENCIES.FCFA;
      const rate = Number((window.swbsRates || {})[currencyKey] || (currencyKey === 'FCFA' ? 1 : 0));
      const base = Number(amount || 0);
      const converted = currencyKey === 'FCFA' ? base : base * rate;
      try {
        return new Intl.NumberFormat(undefined, {
          style: 'currency',
          currency: cur.code,
          maximumFractionDigits: 0,
        }).format(converted);
      } catch (e) {
        return `${converted.toLocaleString()} ${currencyKey}`;
      }
    };

    window.swbsRenderPrices = function renderPrices() {
      document.querySelectorAll('[data-amount]').forEach((el) => {
        const amount = Number(el.getAttribute('data-amount') || '0');
        el.textContent = window.swbsFormatMoney(amount);
      });
    };

    const injectCurrencySelector = () => {
      const nav = document.querySelector('.nav');
      if (!nav) return;
      if (document.querySelector('#swbs-currency')) return;

      const wrap = document.createElement('div');
      wrap.className = 'currency-switch';
      wrap.innerHTML = `
        <select id="swbs-currency" aria-label="Devise">
          <option value="FCFA">FCFA</option>
          <option value="NGN">NAIRA</option>
          <option value="USD">DOLLAR</option>
          <option value="EUR">EURO</option>
        </select>
      `;
      nav.appendChild(wrap);

      const sel = wrap.querySelector('#swbs-currency');
      sel.value = getCurrency();
      sel.addEventListener('change', () => {
        setCurrency(sel.value);
        renderPrices();
      });
    };

    injectCurrencySelector();
    window.swbsRenderPrices();
  }

  async function loadServices() {
    const list = document.querySelector('#services-list');
    if (!list) return;
    try {
      const res = await fetch('/api/services');
      const data = await res.json();
      list.innerHTML = data.services
        .map(
          (s) => `<div class="card" data-animate>
          <div class="service-icon">*</div>
          <h3>${s.title}</h3>
          <p>${s.description}</p>
          <div class="chips"><span class="chip">${s.category}</span></div>
          <button class="btn btn-primary quote-btn" data-service="${s.title}">Demander un devis</button>
        </div>`
        )
        .join('');
    } catch (err) {
      console.error(err);
    }
  }

  async function loadTestimonials() {
    const container = document.querySelector('#testimonials');
    if (!container) return;
    try {
      const res = await fetch('/api/testimonials');
      const data = await res.json();
      container.innerHTML = data.testimonials
        .map(
          (t) => `<div class="card" data-animate>
          <p>"${t.text}"</p>
          <div class="flex"><strong>${t.name}</strong><span class="tag">${'*'.repeat(t.rating)}</span></div>
        </div>`
        )
        .join('');
    } catch (err) {
      console.error(err);
    }
  }
})();

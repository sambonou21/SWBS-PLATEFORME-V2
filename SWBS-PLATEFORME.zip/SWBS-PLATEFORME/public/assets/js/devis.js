document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('#devis-form');
  const estimateEl = document.querySelector('#estimate');
  const whatsappBtn = document.querySelector('#whatsapp-btn');

  if (!form) return;

  // Prefill from querystring (?service=...)
  try {
    const params = new URLSearchParams(window.location.search);
    const svc = params.get('service');
    if (svc) {
      // If no draft, prefill directly
      const current = (form.description && form.description.value) ? form.description.value.trim() : '';
      if (!current) {
        form.description.value = `Je souhaite un devis pour : ${svc}`;
      }
    }
  } catch (e) {}


  // Restore draft (if user was redirected to create an account)
  try {
    const draftRaw = localStorage.getItem('swbs_quote_draft');
    if (draftRaw) {
      const d = JSON.parse(draftRaw);
      if (d.projectType) form.projectType.value = d.projectType;
      if (d.pages) form.pages.value = d.pages;
      form.ecommerce.checked = !!d.ecommerce;
      form.maintenance.checked = !!d.maintenance;
      form.marketing.checked = !!d.marketing;
      form.description.value = d.description || '';
      form.contact.value = d.contact || '';
      localStorage.removeItem('swbs_quote_draft');
    }
  } catch {}

  const compute = () => {
    const type = form.projectType.value;
    const pages = Number(form.pages.value || 1);
    const ecommerce = form.ecommerce.checked;
    const maintenance = form.maintenance.checked;
    const marketing = form.marketing.checked;

    const baseMap = {
      vitrine: 180000,
      ecommerce: 280000,
      logiciel: 320000,
      mobile: 350000,
    };
    let estimate = baseMap[type] || 150000;
    estimate += pages * 10000;
    if (ecommerce) estimate += 80000;
    if (maintenance) estimate += 40000;
    if (marketing) estimate += 35000;

    const min = Math.round(estimate * 0.9);
    const max = Math.round(estimate * 1.2);
    estimateEl.textContent = `${min.toLocaleString('fr-BJ')} FCFA - ${max.toLocaleString('fr-BJ')} FCFA`;
    return { min, max };
  };

  form.addEventListener('input', compute);
  compute();

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    // Require account before sending quote
    const me = await fetch('/api/me', { credentials: 'include' });
    if (me.status === 401) {
      // Save draft then redirect to register (or login)
      const draft = {
        projectType: form.projectType.value,
        pages: Number(form.pages.value || 1),
        ecommerce: form.ecommerce.checked,
        maintenance: form.maintenance.checked,
        marketing: form.marketing.checked,
        description: form.description.value,
        contact: form.contact.value,
      };
      localStorage.setItem('swbs_quote_draft', JSON.stringify(draft));
      const next = encodeURIComponent('/devis');
      window.location.href = `/register?next=${next}`;
      return;
    }

    const { min, max } = compute();
    const payload = {
      type: form.projectType.value,
      pages: Number(form.pages.value || 1),
      ecommerce: form.ecommerce.checked,
      maintenance: form.maintenance.checked,
      marketing: form.marketing.checked,
      description: form.description.value,
      contact: form.contact.value,
    };
    try {
      const csrf = await getCsrfToken();
      await fetch('/api/quotes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(csrf ? { 'X-CSRF-Token': csrf } : {}),
        },
        credentials: 'include',
        body: JSON.stringify({ payload, estimateMin: min, estimateMax: max }),
      });
      showToast('Votre demande est bien reçue. Nous vous rappelons rapidement.');
      if (whatsappBtn) whatsappBtn.href = `https://wa.me/22996368877?text=${encodeURIComponent(
        `Bonjour SWBS, je souhaite un devis pour ${payload.type}. Budget estimé: ${min} - ${max} FCFA. ${payload.description}`
      )}`;
    } catch (err) {
      console.error(err);
    }
  });
});

async function getCsrfToken() {
  try {
    const res = await fetch('/api/csrf', { credentials: 'include' });
    if (!res.ok) return null;
    const data = await res.json();
    return data.csrfToken;
  } catch {
    return null;
  }
}

function showToast(text) {
  const toast = document.querySelector('.toast');
  if (!toast) return;
  toast.textContent = text;
  toast.style.display = 'block';
  setTimeout(() => (toast.style.display = 'none'), 4000);
}

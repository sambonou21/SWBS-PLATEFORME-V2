document.addEventListener('DOMContentLoaded', async () => {
  const presenceSel = document.querySelector('#admin-presence');
  const savePresenceBtn = document.querySelector('#save-presence');
  const rateNgn = document.querySelector('#rate-ngn');
  const rateUsd = document.querySelector('#rate-usd');
  const rateEur = document.querySelector('#rate-eur');
  const saveRatesBtn = document.querySelector('#save-rates');
  const fedapayPublic = document.querySelector('#fedapay-public');
  const fedapaySecret = document.querySelector('#fedapay-secret');
  const fedapayMode = document.querySelector('#fedapay-mode');
  const savePayBtn = document.querySelector('#save-pay');
  const aiKey = document.querySelector('#ai-key');
  const aiMode = document.querySelector('#ai-mode');
  const aiInstructions = document.querySelector('#ai-instructions');
  const saveAiBtn = document.querySelector('#save-ai');
  const badgeQuotes = document.querySelector('#badge-quotes');
  const badgeChat = document.querySelector('#badge-chat');
  const badgeOrders = document.querySelector('#badge-orders');

  if (!presenceSel) return;

  const csrf = await (window.getCsrfToken ? window.getCsrfToken() : null);

  const load = async () => {
    const res = await fetch('/api/admin/settings', { credentials: 'include' });
    if (res.status === 401 || res.status === 403) {
      window.location.href = '/admin/login';
      return;
    }
    const data = await res.json();
    presenceSel.value = data.admin_presence || 'present';
    const rates = data.currency_rates || {};
    if (rateNgn) rateNgn.value = rates.NGN ?? 0;
    if (rateUsd) rateUsd.value = rates.USD ?? 0;
    if (rateEur) rateEur.value = rates.EUR ?? 0;
    if (fedapayPublic) fedapayPublic.value = data.fedapay_public || '';
    if (fedapaySecret) fedapaySecret.value = data.fedapay_secret || '';
    if (fedapayMode) fedapayMode.value = data.fedapay_mode || 'sandbox';
    if (aiKey) aiKey.value = data.ai_api_key || '';
    if (aiMode) aiMode.value = data.ai_mode || 'off';
    if (aiInstructions) aiInstructions.value = data.ai_instructions || '';

    // petites stats pour badges
    try {
      const st = await fetch('/api/admin/stats', { credentials: 'include' });
      if (st.ok) {
        const stats = (await st.json()).stats || {};
        if (badgeQuotes) badgeQuotes.textContent = `Devis: ${stats.quotesOpen ?? stats.quotes ?? 0}`;
        if (badgeChat) badgeChat.textContent = `Chat: ${stats.conversations ?? 0}`;
        if (badgeOrders) badgeOrders.textContent = `Cmd: ${stats.orders ?? 0}`;
      }
    } catch {}
  };

  const save = async (payload) => {
    const res = await fetch('/api/admin/settings', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...(csrf ? { 'X-CSRF-Token': csrf } : {}),
      },
      body: JSON.stringify(payload),
      credentials: 'include',
    });
    if (!res.ok) {
      alert('Erreur sauvegarde paramètres');
      return;
    }
    alert('Paramètres enregistrés.');
  };

  savePresenceBtn?.addEventListener('click', () => {
    save({ admin_presence: presenceSel.value });
  });

  saveRatesBtn?.addEventListener('click', () => {
    save({
      currency_rates: {
        FCFA: 1,
        NGN: Number(rateNgn?.value || 0),
        USD: Number(rateUsd?.value || 0),
        EUR: Number(rateEur?.value || 0),
      },
    });
  });

  savePayBtn?.addEventListener('click', () => {
    save({
      fedapay_public: fedapayPublic?.value || '',
      fedapay_secret: fedapaySecret?.value || '',
      fedapay_mode: fedapayMode?.value || 'sandbox',
    });
  });

  saveAiBtn?.addEventListener('click', () => {
    save({
      ai_api_key: aiKey?.value || '',
      ai_mode: aiMode?.value || 'off',
      ai_instructions: aiInstructions?.value || '',
    });
  });

  load();
});

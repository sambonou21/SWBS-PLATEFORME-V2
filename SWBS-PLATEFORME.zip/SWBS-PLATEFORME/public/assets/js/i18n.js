(() => {
  const LANG_KEY = 'swbs_lang';

  async function loadDict(lang) {
    try {
      const res = await fetch(`/assets/i18n/${lang}.json`);
      if (!res.ok) return null;
      return res.json();
    } catch {
      return null;
    }
  }

  function applyTranslations(dict) {
    if (!dict) return;
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      const key = el.getAttribute('data-i18n');
      if (dict[key]) el.textContent = dict[key];
    });
    document.documentElement.setAttribute('lang', currentLang());
  }

  function currentLang() {
    return localStorage.getItem(LANG_KEY) || 'fr';
  }

  async function setLang(lang) {
    localStorage.setItem(LANG_KEY, lang);
    const dict = await loadDict(lang);
    applyTranslations(dict);
  }

  document.addEventListener('DOMContentLoaded', async () => {
    const lang = currentLang();
    const dict = await loadDict(lang);
    applyTranslations(dict);

    document.querySelectorAll('[data-lang]').forEach((btn) =>
      btn.addEventListener('click', () => setLang(btn.getAttribute('data-lang')))
    );
  });

  window.swbsSetLang = setLang;
  window.swbsCurrentLang = currentLang;
})();

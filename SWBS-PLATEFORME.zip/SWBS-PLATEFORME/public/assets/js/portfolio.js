document.addEventListener('DOMContentLoaded', () => {
  const filters = document.querySelectorAll('[data-filter]');
  const list = document.querySelector('#portfolio-list');
  const modal = document.querySelector('#portfolio-modal');
  const modalBody = document.querySelector('#portfolio-modal-body');

  let data = [];
  let active = 'all';

  if (!list) return;

  fetch('/api/portfolio')
    .then((r) => r.json())
    .then((res) => {
      data = res.portfolio || [];
      render();
    })
    .catch(console.error);

  filters.forEach((btn) =>
    btn.addEventListener('click', () => {
      active = btn.dataset.filter;
      filters.forEach((b) => b.classList.toggle('active', b === btn));
      render();
    })
  );

  function render() {
    const filtered = data.filter((item) => active === 'all' || item.category === active);
    list.innerHTML = filtered
      .map(
        (p) => `<div class="card" data-id="${p.id}">
        <div style="height:160px;background:var(--border);border-radius:12px;margin-bottom:12px;"></div>
        <div class="chips"><span class="chip">${p.category}</span></div>
        <h3>${p.title}</h3>
        <p>${p.description}</p>
        <button class="cta ghost" data-view="${p.id}">Voir le detail</button>
      </div>`
      )
      .join('');

    list.querySelectorAll('[data-view]').forEach((btn) =>
      btn.addEventListener('click', () => {
        const item = data.find((i) => i.id === Number(btn.dataset.view));
        if (!item) return;
        modalBody.innerHTML = `
          <h3>${item.title}</h3>
          <p>${item.details || item.description}</p>
          <div class="chips">${(JSON.parse(item.tagsJson || '[]') || [])
            .map((t) => `<span class="chip">${t}</span>`)
            .join('')}</div>
          <a class="cta" href="/devis">Demander un devis</a>
        `;
        if (modal) {
          modal.classList.add('open');
          modal.style.display = 'block';
        }
      })
    );
  }

  document.querySelectorAll('[data-modal-close]').forEach((btn) =>
    btn.addEventListener('click', () => {
      if (modal) {
        modal.classList.remove('open');
        modal.style.display = 'none';
      }
    })
  );
});

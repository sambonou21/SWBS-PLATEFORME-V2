document.addEventListener('DOMContentLoaded', () => {
  const stats = document.querySelectorAll('.stat');
  if (!stats.length) return;

  const obs = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      const target = entry.target;
      const end = parseInt(target.dataset.end || '0', 10);
      let i = 0;
      const step = setInterval(() => {
        i += Math.max(1, Math.round(end / 50));
        if (i >= end) { i = end; clearInterval(step); }
        const strong = target.querySelector('strong');
        if (strong) strong.textContent = i;
      }, 40);
      obs.unobserve(target);
    });
  }, { threshold: 0.3 });

  stats.forEach(s => obs.observe(s));
});

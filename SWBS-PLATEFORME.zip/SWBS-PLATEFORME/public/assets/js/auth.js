document.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  const next = params.get('next') || '';
  const nextUrl = next && next.startsWith('/') ? next : '';

  const getCsrf = async () => {
    try {
      const res = await fetch('/api/csrf', { credentials: 'include' });
      if (!res.ok) return null;
      const data = await res.json();
      return data.csrfToken;
    } catch {
      return null;
    }
  };
  const registerForm = document.querySelector('#register-form');
  const loginForm = document.querySelector('#login-form');
  const adminLoginForm = document.querySelector('#admin-login-form');

  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(registerForm).entries());
      if (!body.email || !body.password) return alert('Email et mot de passe requis');
      const csrf = await getCsrf();
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(csrf ? { 'X-CSRF-Token': csrf } : {}) },
        credentials: 'include',
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) return alert(data.error || data.errors?.join(', '));
      alert(data.message || 'Compte créé. Vérifiez vos emails pour activer votre compte.');
      window.location.href = '/login';
    });
  }

  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(loginForm).entries());
      const csrf = await getCsrf();
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(csrf ? { 'X-CSRF-Token': csrf } : {}) },
        credentials: 'include',
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) return alert(data.error || 'Connexion impossible');
      window.location.href = nextUrl || '/chat';
    });
  }

  if (adminLoginForm) {
    adminLoginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(adminLoginForm).entries());
      const csrf = await getCsrf();
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(csrf ? { 'X-CSRF-Token': csrf } : {}) },
        credentials: 'include',
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) return alert(data.error || 'Connexion impossible');
      if (data.user?.role !== 'admin') return alert('Accès admin requis');
      window.location.href = '/admin/dashboard';
    });
  }
});

document.addEventListener('DOMContentLoaded', () => {
  loadQuotes();
  loadMessages();
  loadOrders();
});

async function fetchJson(url) {
  const res = await fetch(url, { credentials: 'include' });
  if (res.status === 401 || res.status === 403) {
    window.location.href = `/login?next=${encodeURIComponent('/dashboard')}`;
    return null;
  }
  if (!res.ok) return null;
  return res.json();
}

function renderStatus(status) {
  const map = {
    received: { label: 'Recu', class: 'pill-warning' },
    in_progress: { label: 'En cours', class: 'pill-warning' },
    approved: { label: 'Valide', class: 'pill-success' },
    rejected: { label: 'Refuse', class: 'pill-warning' },
    pending: { label: 'En attente', class: 'pill-warning' },
    paid: { label: 'Payee', class: 'pill-success' },
    delivered: { label: 'Livree', class: 'pill-success' },
    canceled: { label: 'Annulee', class: 'pill-warning' },
  };
  const meta = map[status] || { label: status || 'N/A', class: 'pill-warning' };
  return `<span class="tag ${meta.class}">${meta.label}</span>`;
}

async function loadQuotes() {
  const data = await fetchJson('/api/client/quotes');
  if (!data) return;
  const tbody = document.querySelector('#quotes-table tbody');
  if (!tbody) return;
  document.querySelector('#stat-quotes').textContent = data.quotes?.length || 0;
  tbody.innerHTML = (data.quotes || [])
    .map((q) => {
      const payload = JSON.parse(q.payloadJson || '{}');
      const est = q.estimateMin && q.estimateMax ? `${q.estimateMin} - ${q.estimateMax} FCFA` : '-';
      return `<tr>
        <td>${q.id}</td>
        <td>${payload.type || 'N/A'}</td>
        <td>${est}</td>
        <td>${renderStatus(q.status)}</td>
        <td>${new Date(q.createdAt).toLocaleString()}</td>
      </tr>`;
    })
    .join('');
}

async function loadMessages() {
  const box = document.querySelector('#messages-list');
  if (!box) return;
  const data = await fetchJson('/api/client/messages');
  if (!data) return;
  const msgs = data.messages || [];
  document.querySelector('#stat-messages').textContent = msgs.length;
  box.innerHTML =
    msgs
      .map(
        (m) => `<div class="bubble ${m.senderRole === 'client' ? 'me' : 'them'}">
        <small>${new Date(m.createdAt).toLocaleString()}</small><br>${m.body}
      </div>`
      )
      .join('') || '<div class="muted">Aucun message pour le moment.</div>';
}

async function loadOrders() {
  const tbody = document.querySelector('#orders-table tbody');
  if (!tbody) return;
  const data = await fetchJson('/api/client/orders');
  if (!data) return;
  const orders = data.orders || [];
  document.querySelector('#stat-orders').textContent = orders.length;
  if (!orders.length) {
    tbody.innerHTML = '<tr><td colspan="4">Aucune commande pour le moment.</td></tr>';
    return;
  }
  tbody.innerHTML = orders
    .map(
      (o) => `<tr>
        <td>${o.reference || o.id}</td>
        <td>${o.total ? o.total + ' ' + (o.currency || 'FCFA') : '-'}</td>
        <td>${renderStatus(o.status || '')}</td>
        <td>${new Date(o.createdAt).toLocaleString()}</td>
      </tr>`
    )
    .join('');
}

document.addEventListener('DOMContentLoaded', async () => {
  const msg = document.querySelector('#msg');
  const btn = document.querySelector('#go-login');
  try {
    const params = new URLSearchParams(window.location.search);
    const token = params.get('token');
    if (!token) {
      msg.textContent = "Token manquant.";
      return;
    }
    const res = await fetch('/api/auth/verify-email', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token }),
      credentials: 'include',
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      msg.textContent = data.error || "Vérification impossible.";
      return;
    }
    msg.textContent = data.message || "Email validé. Vous pouvez vous connecter.";
    if (btn) btn.style.display = 'inline-block';
  } catch (e) {
    msg.textContent = "Erreur réseau. Réessayez.";
  }
});

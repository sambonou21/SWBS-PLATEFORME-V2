const express = require('express');
const { all, run } = require('../lib/db');
const { requireAdmin } = require('../middleware/auth');
const { validatePayload } = require('../middleware/validate');

const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const testimonials = await all('SELECT * FROM testimonials ORDER BY createdAt DESC');
    res.json({ testimonials });
  } catch (err) {
    next(err);
  }
});

router.post(
  '/',
  requireAdmin,
  validatePayload({
    name: { required: true },
    rating: { required: true },
    text: { required: true },
  }),
  async (req, res, next) => {
    try {
      const { name, rating, text } = req.body;
      const result = await run(
        'INSERT INTO testimonials (name, rating, text, createdAt) VALUES (?,?,?,CURRENT_TIMESTAMP)',
        [name, Number(rating), text]
      );
      res.json({ id: result.lastID });
    } catch (err) {
      next(err);
    }
  }
);

router.put('/:id', requireAdmin, async (req, res, next) => {
  try {
    const { name, rating, text } = req.body;
    await run('UPDATE testimonials SET name=?, rating=?, text=? WHERE id=?', [
      name,
      Number(rating),
      text,
      req.params.id,
    ]);
    res.json({ message: 'Avis mis à jour' });
  } catch (err) {
    next(err);
  }
});

router.delete('/:id', requireAdmin, async (req, res, next) => {
  try {
    await run('DELETE FROM testimonials WHERE id=?', [req.params.id]);
    res.json({ message: 'Avis supprimé' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

const express = require('express');
// Use bcryptjs (pure JS) to avoid native compilation issues on shared hosts.
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { sendMail } = require('../lib/mailer');
const { run, get } = require('../lib/db');
const { validatePayload } = require('../middleware/validate');

const router = express.Router();

router.post(
  '/register',
  validatePayload({
    firstName: { required: true },
    lastName: { required: true },
    email: { required: true, type: 'email' },
    phone: { required: true, type: 'phone' },
    password: { required: true, minLength: 8 },
  }),
  async (req, res, next) => {
    try {
      const { firstName, lastName, email, phone, password } = req.body;
      const cleanEmail = String(email || '').toLowerCase().trim();
      const existing = await get('SELECT id FROM users WHERE email = ?', [cleanEmail]);
      if (existing) {
        return res.status(400).json({ error: 'Un compte existe deja avec cet email.' });
      }

      const passwordHash = await bcrypt.hash(password, 10);
      const token = crypto.randomBytes(32).toString('hex');
      const expires = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

      await run(
        'INSERT INTO users (role, firstName, lastName, email, phone, passwordHash, isActive, emailVerified, emailVerifyToken, emailVerifyExpires) VALUES (?,?,?,?,?,?,?,?,?,?)',
        ['client', firstName, lastName, cleanEmail, phone, passwordHash, 0, 0, token, expires]
      );

      const baseUrl = process.env.APP_BASE_URL || `http://localhost:${process.env.PORT || 3000}`;
      const verifyUrl = `${baseUrl}/verify-email?token=${encodeURIComponent(token)}`;

      const html = `
        <div style="font-family:Arial,Helvetica,sans-serif; background:#f6f8fb; padding:24px;">
          <div style="max-width:620px;margin:0 auto;background:#ffffff;border-radius:18px;overflow:hidden;border:1px solid rgba(15,23,42,0.08);">
            <div style="padding:18px 22px;background:#0f172a;color:#fff;">
              <div style="display:flex;align-items:center;gap:12px;">
                <div style="width:38px;height:38px;border-radius:12px;background:#1E66FF;display:inline-flex;align-items:center;justify-content:center;font-weight:800;">SW</div>
                <div>
                  <div style="font-size:16px;font-weight:800;line-height:1;">Sam Web Business Services</div>
                  <div style="font-size:12px;opacity:.85;">Validation d'inscription</div>
                </div>
              </div>
            </div>
            <div style="padding:22px;">
              <h2 style="margin:0 0 8px 0;color:#0f172a;">Confirme ton email</h2>
              <p style="margin:0 0 16px 0;color:rgba(15,23,42,0.72);line-height:1.5;">
                Bonjour ${firstName}, pour activer ton compte SWBS, clique sur le bouton ci-dessous.
              </p>
              <p style="margin:0 0 18px 0;">
                <a href="${verifyUrl}" style="display:inline-block;background:#1E66FF;color:#fff;text-decoration:none;padding:12px 16px;border-radius:12px;font-weight:800;">
                  ✔ Valider mon email
                </a>
              </p>
              <p style="margin:0;color:rgba(15,23,42,0.65);font-size:12px;line-height:1.5;">
                Lien valable 24h. Si tu n'es pas a l'origine de cette inscription, ignore ce message.
              </p>
              <hr style="border:none;border-top:1px solid rgba(15,23,42,0.08);margin:18px 0;">
              <p style="margin:0;color:rgba(15,23,42,0.65);font-size:12px;">
                SWBS • Plateforme client • Support: ${process.env.MAIL_FROM || 'contact@swbs.com'}
              </p>
            </div>
          </div>
        </div>
      `;

      await sendMail({ to: cleanEmail, subject: 'SWBS - Validation de votre email', html });

      res.json({ message: 'Inscription reussie. Verifiez vos emails pour activer votre compte.' });
    } catch (err) {
      next(err);
    }
  }
);

router.post('/verify-email', async (req, res, next) => {
  try {
    const { token } = req.body || {};
    if (!token) return res.status(400).json({ error: 'Token manquant' });

    const user = await get('SELECT * FROM users WHERE emailVerifyToken = ?', [token]);
    if (!user) return res.status(400).json({ error: 'Token invalide' });

    if (user.emailVerifyExpires && new Date(user.emailVerifyExpires).getTime() < Date.now()) {
      return res.status(400).json({ error: 'Token expire' });
    }

    await run(
      'UPDATE users SET emailVerified = 1, isActive = 1, emailVerifyToken = NULL, emailVerifyExpires = NULL WHERE id = ?',
      [user.id]
    );

    res.json({ ok: true, message: 'Email valide. Vous pouvez vous connecter.' });
  } catch (err) {
    next(err);
  }
});

router.post(
  '/login',
  validatePayload({
    email: { required: true, type: 'email' },
    password: { required: true, minLength: 6 },
  }),
  async (req, res, next) => {
    try {
      const { email, password } = req.body;
      const cleanEmail = String(email || '').toLowerCase().trim();
      const user = await get('SELECT * FROM users WHERE email = ?', [cleanEmail]);
      if (!user) {
        return res.status(400).json({ error: 'Identifiants invalides' });
      }
      const ok = await bcrypt.compare(password, user.passwordHash);
      if (!ok) {
        return res.status(400).json({ error: 'Identifiants invalides' });
      }
      if (user.emailVerified === 0) {
        return res.status(403).json({ error: 'Veuillez valider votre email avant de vous connecter.' });
      }
      if (user.isActive === 0) {
        return res.status(403).json({ error: 'Compte desactive' });
      }
      req.session.user = {
        id: user.id,
        role: user.role,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        phone: user.phone,
        isActive: user.isActive,
        emailVerified: user.emailVerified,
      };
      res.json({ message: 'Connexion reussie', user: req.session.user });
    } catch (err) {
      next(err);
    }
  }
);

router.post('/logout', (req, res, next) => {
  if (!req.session) return res.json({ message: 'Deconnecte' });
  req.session.destroy((err) => {
    if (err) return next(err);
    res.clearCookie('connect.sid');
    res.json({ message: 'Deconnecte' });
  });
});

router.get('/logout', (req, res, next) => {
  if (!req.session) return res.redirect('/');
  req.session.destroy((err) => {
    if (err) return next(err);
    res.clearCookie('connect.sid');
    res.redirect('/');
  });
});

module.exports = router;

const express = require('express');
const { all, run } = require('../lib/db');
const { requireAdmin } = require('../middleware/auth');
const { validatePayload } = require('../middleware/validate');

function sanitizeUploadPath(p) {
  if (!p) return '';
  return p.startsWith('/uploads/') ? p : '';
}

const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const params = [];
    let query = 'SELECT * FROM portfolio';
    if (req.query.category) {
      query += ' WHERE category = ?';
      params.push(req.query.category);
    }
    query += ' ORDER BY createdAt DESC';
    const items = await all(query, params);
    res.json({ portfolio: items });
  } catch (err) {
    next(err);
  }
});

router.post(
  '/',
  requireAdmin,
  validatePayload({
    title: { required: true },
    category: { required: true },
    description: { required: true },
  }),
  async (req, res, next) => {
    try {
      const { title, category, tagsJson, description, details, imageUrl } = req.body;
      const safeImage = sanitizeUploadPath(imageUrl);
      const result = await run(
        'INSERT INTO portfolio (title, category, tagsJson, description, details, imageUrl, createdAt, updatedAt) VALUES (?,?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)',
        [title, category, tagsJson || '[]', description, details || '', safeImage]
      );
      res.json({ id: result.lastID });
    } catch (err) {
      next(err);
    }
  }
);

router.put('/:id', requireAdmin, async (req, res, next) => {
  try {
    const { title, category, tagsJson, description, details, imageUrl } = req.body;
    const safeImage = sanitizeUploadPath(imageUrl);
    await run(
      'UPDATE portfolio SET title=?, category=?, tagsJson=?, description=?, details=?, imageUrl=?, updatedAt=CURRENT_TIMESTAMP WHERE id=?',
      [title, category, tagsJson || '[]', description, details || '', safeImage, req.params.id]
    );
    res.json({ message: 'Portfolio mis à jour' });
  } catch (err) {
    next(err);
  }
});

router.delete('/:id', requireAdmin, async (req, res, next) => {
  try {
    await run('DELETE FROM portfolio WHERE id=?', [req.params.id]);
    res.json({ message: 'Portfolio supprimé' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

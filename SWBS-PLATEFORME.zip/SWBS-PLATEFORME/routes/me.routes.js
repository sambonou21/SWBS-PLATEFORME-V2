const express = require('express');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const { all, run, get, columnExists } = require('../lib/db');

const router = express.Router();

router.get('/me', (req, res) => {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ error: 'Non authentifié' });
  }
  res.json({ user: req.session.user });
});

// Admin: liste clients
router.get('/admin/clients', requireAdmin, async (req, res, next) => {
  try {
    const clients = await all(
      'SELECT id, firstName, lastName, email, phone, isActive, createdAt FROM users WHERE role = ? ORDER BY createdAt DESC',
      ['client']
    );
    res.json({ clients });
  } catch (err) {
    next(err);
  }
});

router.put('/admin/clients/:id/status', requireAdmin, async (req, res, next) => {
  try {
    const { isActive } = req.body;
    await run('UPDATE users SET isActive = ? WHERE id = ? AND role = ?', [isActive ? 1 : 0, req.params.id, 'client']);
    res.json({ message: 'Statut mis à jour' });
  } catch (err) {
    next(err);
  }
});

router.get('/admin/stats', requireAdmin, async (req, res, next) => {
  try {
    const [clients] = await all("SELECT COUNT(*) as total FROM users WHERE role='client'");
    const [conversations] = await all('SELECT COUNT(*) as total FROM conversations');
    const [messagesToday] = await all(
      "SELECT COUNT(*) as total FROM messages WHERE DATE(createdAt) = DATE('now','localtime')"
    );
    const [quotes] = await all('SELECT COUNT(*) as total FROM quotes');
    const [quotesOpen] = await all("SELECT COUNT(*) as total FROM quotes WHERE status IN ('received','in_progress')");
    let orders = { total: 0 };
    try {
      const hasOrders = await columnExists('orders', 'id');
      if (hasOrders) {
        const [row] = await all('SELECT COUNT(*) as total FROM orders');
        orders = row || { total: 0 };
      }
    } catch {}
    res.json({
      stats: {
        clients: clients?.total || 0,
        conversations: conversations?.total || 0,
        messagesToday: messagesToday?.total || 0,
        quotes: quotes?.total || 0,
        quotesOpen: quotesOpen?.total || 0,
        orders: orders?.total || 0,
      },
    });
  } catch (err) {
    next(err);
  }
});

// Client: mes devis
router.get('/client/quotes', requireAuth, async (req, res, next) => {
  try {
    const quotes = await all(
      'SELECT * FROM quotes WHERE clientUserId = ? ORDER BY createdAt DESC',
      [req.session.user.id]
    );
    res.json({ quotes });
  } catch (err) {
    next(err);
  }
});

// Client: mes messages (derniere conversation)
router.get('/client/messages', requireAuth, async (req, res, next) => {
  try {
    const convo = await get('SELECT * FROM conversations WHERE clientUserId = ? ORDER BY id DESC LIMIT 1', [
      req.session.user.id,
    ]);
    if (!convo) return res.json({ conversation: null, messages: [] });
    const messages = await all('SELECT * FROM messages WHERE conversationId = ? ORDER BY createdAt ASC', [convo.id]);
    res.json({ conversation: convo, messages });
  } catch (err) {
    next(err);
  }
});

// Client: mes commandes (sera alimente par le module boutique)
router.get('/client/orders', requireAuth, async (req, res, next) => {
  try {
    // Si la table orders n'existe pas encore (avant module boutique), renvoyer vide
    try {
      const hasOrders = await columnExists('orders', 'id');
      if (!hasOrders) return res.json({ orders: [] });
    } catch (e) {
      return res.json({ orders: [] });
    }
    const orders = await all(
      'SELECT * FROM orders WHERE clientUserId = ? ORDER BY createdAt DESC',
      [req.session.user.id]
    );
    res.json({ orders });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

const express = require('express');
const { all, get, run } = require('../lib/db');
const { requireAdmin } = require('../middleware/auth');

function sanitizeUploadPath(p) {
  if (!p) return '';
  return p.startsWith('/uploads/') ? p : '';
}

const router = express.Router();

// Public list
router.get('/', async (req, res, next) => {
  try {
    const params = [];
    let sql = "SELECT p.*, c.name as categoryName FROM products p LEFT JOIN product_categories c ON c.id = p.categoryId WHERE p.status = 'published'";
    if (req.query.category) {
      sql += ' AND c.slug = ?';
      params.push(req.query.category);
    }
    sql += ' ORDER BY p.createdAt DESC';
    const products = await all(sql, params);
    res.json({ products });
  } catch (err) {
    next(err);
  }
});

// Public detail by slug
router.get('/:slug', async (req, res, next) => {
  try {
    const product = await get(
      "SELECT p.*, c.name as categoryName, c.slug as categorySlug FROM products p LEFT JOIN product_categories c ON c.id = p.categoryId WHERE p.slug = ? AND p.status = 'published' LIMIT 1",
      [req.params.slug]
    );
    if (!product) return res.status(404).json({ error: 'Produit introuvable' });
    res.json({ product });
  } catch (err) {
    next(err);
  }
});

// Admin: create/update/delete
router.post('/admin', requireAdmin, async (req, res, next) => {
  try {
    const { title, slug, categoryId, description, price, stock, imageUrl, status } = req.body || {};
    if (!title || !slug || !description || !price) {
      return res.status(400).json({ error: 'Champs requis manquants' });
    }
    const safeImage = sanitizeUploadPath(imageUrl);
    const result = await run(
      'INSERT INTO products (title, slug, categoryId, description, price, stock, imageUrl, status, createdAt, updatedAt) VALUES (?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)',
      [
        title,
        slug,
        categoryId || null,
        description,
        Number(price),
        Number(stock || 0),
        safeImage,
        status || 'published',
      ]
    );
    res.json({ id: result.lastID || result.insertId });
  } catch (err) {
    next(err);
  }
});

router.put('/admin/:id', requireAdmin, async (req, res, next) => {
  try {
    const { title, slug, categoryId, description, price, stock, imageUrl, status } = req.body || {};
    const safeImage = sanitizeUploadPath(imageUrl);
    await run(
      'UPDATE products SET title=?, slug=?, categoryId=?, description=?, price=?, stock=?, imageUrl=?, status=?, updatedAt=CURRENT_TIMESTAMP WHERE id=?',
      [
        title,
        slug,
        categoryId || null,
        description,
        Number(price),
        Number(stock || 0),
        safeImage,
        status || 'published',
        req.params.id,
      ]
    );
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

router.delete('/admin/:id', requireAdmin, async (req, res, next) => {
  try {
    await run('DELETE FROM products WHERE id = ?', [req.params.id]);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

// Admin: list (with unpublished)
router.get('/admin/list/all', requireAdmin, async (req, res, next) => {
  try {
    const products = await all(
      'SELECT p.*, c.name as categoryName FROM products p LEFT JOIN product_categories c ON c.id = p.categoryId ORDER BY p.createdAt DESC'
    );
    res.json({ products });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

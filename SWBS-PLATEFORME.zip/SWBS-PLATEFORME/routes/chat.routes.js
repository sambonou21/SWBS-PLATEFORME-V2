const express = require('express');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const { all, get, run } = require('../lib/db');

const router = express.Router();

router.post('/chat/guest-start', async (req, res, next) => {
  try {
    const { name, email, phone } = req.body || {};
    if (!name || !email || !phone) return res.status(400).json({ error: 'Champs manquants' });

    // Reuse existing client account if email exists
    const existingUser = await get('SELECT id FROM users WHERE email = ?', [email.toLowerCase()]);
    let convo;
    if (existingUser) {
      // create conversation tied to user
      convo = await get('SELECT * FROM conversations WHERE clientUserId = ? ORDER BY id DESC LIMIT 1', [existingUser.id]);
      if (!convo) {
        const r = await run(
          'INSERT INTO conversations (clientUserId, status, createdAt, updatedAt) VALUES (?,\'open\',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)',
          [existingUser.id]
        );
        convo = await get('SELECT * FROM conversations WHERE id = ?', [r.insertId || r.lastID]);
      }
      req.session.guest = { conversationId: convo.id, name, email, phone, linkedUserId: existingUser.id };
    } else {
      const r = await run(
        'INSERT INTO conversations (clientUserId, leadName, leadEmail, leadPhone, status, createdAt, updatedAt) VALUES (NULL,?,?,?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)',
        [name, email.toLowerCase(), phone, 'open']
      );
      const convoId = r.insertId || r.lastID;
      convo = await get('SELECT * FROM conversations WHERE id = ?', [convoId]);
      req.session.guest = { conversationId: convoId, name, email: email.toLowerCase(), phone };
    }

    res.json({ conversation: convo });
  } catch (err) {
    next(err);
  }
});

router.get('/chat/guest-conversation', async (req, res) => {
  const convoId = req.session?.guest?.conversationId;
  if (!convoId) return res.status(401).json({ error: 'No guest session' });
  const convo = await get('SELECT * FROM conversations WHERE id = ?', [convoId]);
  res.json({ conversation: convo || null });
});


router.get('/chat/my-conversation', requireAuth, async (req, res, next) => {
  try {
    const convo = await get('SELECT * FROM conversations WHERE clientUserId = ? ORDER BY id DESC LIMIT 1', [
      req.session.user.id,
    ]);
    res.json({ conversation: convo || null });
  } catch (err) {
    next(err);
  }
});

router.post('/chat/start', requireAuth, async (req, res, next) => {
  try {
    const existing = await get('SELECT * FROM conversations WHERE clientUserId = ? ORDER BY id DESC LIMIT 1', [
      req.session.user.id,
    ]);
    if (existing) {
      return res.json({ conversationId: existing.id });
    }
    const result = await run(
      'INSERT INTO conversations (clientUserId, status, createdAt, updatedAt) VALUES (?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)',
      [req.session.user.id, 'open']
    );
    res.json({ conversationId: result.lastID });
  } catch (err) {
    next(err);
  }
});

router.get('/chat/messages/:conversationId', async (req, res, next) => {
  try {
    const convo = await get('SELECT * FROM conversations WHERE id = ?', [req.params.conversationId]);
    if (!convo) {
      return res.status(404).json({ error: 'Conversation introuvable' });
    }
    const user = req.session?.user;
    const guest = req.session?.guest;
    if (user?.role === 'client' && convo.clientUserId !== user.id) {
      return res.status(403).json({ error: 'Acces refuse' });
    }
    if (!user && (!guest || String(guest.conversationId) !== String(convo.id))) {
      return res.status(401).json({ error: 'Non autorise' });
    }
    const messages = await all(
      'SELECT * FROM messages WHERE conversationId = ? ORDER BY createdAt ASC',
      [req.params.conversationId]
    );
    res.json({ messages });
  } catch (err) {
    next(err);
  }
});

router.get('/admin/conversations', requireAdmin, async (req, res, next) => {
  try {
    const conversations = await all(
      `SELECT c.*, u.firstName, u.lastName, u.email,
        (SELECT COUNT(*) FROM messages m WHERE m.conversationId = c.id AND m.senderRole = 'client' AND m.isRead = 0) AS unreadClient
       FROM conversations c
       LEFT JOIN users u ON u.id = c.clientUserId
       ORDER BY c.updatedAt DESC`
    );
    res.json({ conversations });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

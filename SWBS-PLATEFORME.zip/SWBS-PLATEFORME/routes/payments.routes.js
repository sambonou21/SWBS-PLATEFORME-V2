const express = require('express');
const crypto = require('crypto');
const { requireAuth } = require('../middleware/auth');
const { get, run } = require('../lib/db');
const { getSetting } = require('../lib/settings');

const router = express.Router();

// Initiate Fedapay checkout (placeholder URL built from settings)
router.post('/payments/fedapay/checkout', requireAuth, async (req, res, next) => {
  try {
    const { orderId } = req.body || {};
    if (!orderId) return res.status(400).json({ error: 'orderId requis' });
    const order = await get('SELECT * FROM orders WHERE id = ? AND clientUserId = ?', [orderId, req.session.user.id]);
    if (!order) return res.status(404).json({ error: 'Commande introuvable' });
    if (order.status !== 'pending') return res.status(400).json({ error: 'Commande deja traitee' });

    const publicKey = await getSetting('fedapay_public', process.env.FEDAPAY_PUBLIC || '');
    const secret = await getSetting('fedapay_secret', process.env.FEDAPAY_SECRET || '');
    const mode = await getSetting('fedapay_mode', process.env.FEDAPAY_MODE || 'sandbox');
    if (!publicKey || !secret) return res.status(400).json({ error: 'Fedapay non configure' });

    const reference = order.reference || `ORD-${orderId}-${Date.now()}`;
    await run(
      'UPDATE orders SET reference = ?, paymentProvider = ?, paymentRef = ?, paymentMode = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?',
      [reference, 'fedapay', reference, mode, orderId]
    );

    // Placeholder checkout URL (replace with real Fedapay session creation in production)
    const base = mode === 'live' ? 'https://pay.fedapay.com' : 'https://sandbox-pay.fedapay.com';
    const callback = `${process.env.APP_BASE_URL || ''}/dashboard`;
    const checkoutUrl = `${base}/checkout/${reference}?amount=${order.total}&currency=${order.currency}&callback=${encodeURIComponent(
      callback
    )}`;

    res.json({ checkoutUrl, reference, publicKey, amount: order.total, currency: order.currency });
  } catch (err) {
    next(err);
  }
});

// Webhook Fedapay (signature: HMAC SHA256 body with secret)
router.post('/webhook/fedapay', express.json({ type: 'application/json' }), async (req, res) => {
  const secret = (await getSetting('fedapay_secret', process.env.FEDAPAY_SECRET || '')) || '';
  const signature = req.headers['x-fedapay-signature'] || '';
  const rawBody = JSON.stringify(req.body || {});
  const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
  if (!secret || signature !== expected) {
    return res.status(400).json({ error: 'Signature invalide' });
  }
  const event = req.body || {};
  const orderId = event.metadata?.orderId || event.orderId;
  const ref = event.reference || event.metadata?.reference;
  const status = event.status;
  if (!orderId && !ref) return res.json({ ok: true });

  // idempotent update
  let order = null;
  if (orderId) order = await get('SELECT * FROM orders WHERE id = ?', [orderId]);
  if (!order && ref) order = await get('SELECT * FROM orders WHERE reference = ?', [ref]);
  if (!order) return res.json({ ok: true });
  if (order.status === 'paid') return res.json({ ok: true });

  if (status === 'paid' || status === 'approved') {
    await run('UPDATE orders SET status = ?, paymentRef = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?', [
      'paid',
      ref || order.paymentRef || '',
      order.id,
    ]);
  }
  res.json({ ok: true });
});

module.exports = router;

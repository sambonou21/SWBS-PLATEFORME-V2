const express = require('express');
const { requireAdmin } = require('../middleware/auth');
const { get, run } = require('../lib/db');
const { getCurrencyRates } = require('../lib/settings');

const router = express.Router();

async function getSetting(key, fallback) {
  const row = await get('SELECT value FROM app_settings WHERE `key` = ?', [key]);
  if (!row) return fallback;
  return row.value;
}

async function setSetting(key, value) {
  try {
    await run(
      'INSERT INTO app_settings(`key`, value) VALUES(?, ?) ON CONFLICT(`key`) DO UPDATE SET value=excluded.value, updatedAt=CURRENT_TIMESTAMP',
      [key, value]
    );
  } catch (err) {
    // MySQL fallback
    await run(
      'INSERT INTO app_settings(`key`, value) VALUES(?, ?) ON DUPLICATE KEY UPDATE value=VALUES(value), updatedAt=CURRENT_TIMESTAMP',
      [key, value]
    );
  }
}

router.get('/admin/settings', requireAdmin, async (req, res, next) => {
  try {
    const admin_presence = await getSetting('admin_presence', 'present');
    const currency_rates = await getSetting('currency_rates', '{"FCFA":1,"NGN":0,"USD":0,"EUR":0}');
    const fedapay_public = await getSetting('fedapay_public', process.env.FEDAPAY_PUBLIC || '');
    const fedapay_secret = await getSetting('fedapay_secret', process.env.FEDAPAY_SECRET || '');
    const fedapay_mode = await getSetting('fedapay_mode', process.env.FEDAPAY_MODE || 'sandbox');
    const ai_api_key = await getSetting('ai_api_key', process.env.AI_API_KEY || '');
    const ai_mode = await getSetting('ai_mode', process.env.AI_MODE || 'off');
    const ai_instructions = await getSetting('ai_instructions', process.env.AI_INSTRUCTIONS || '');
    res.json({
      admin_presence,
      currency_rates: JSON.parse(currency_rates),
      fedapay_public,
      fedapay_secret,
      fedapay_mode,
      ai_api_key,
      ai_mode,
      ai_instructions,
    });
  } catch (err) {
    next(err);
  }
});

router.put('/admin/settings', requireAdmin, async (req, res, next) => {
  try {
    const { admin_presence, currency_rates, fedapay_public, fedapay_secret, fedapay_mode, ai_api_key, ai_mode, ai_instructions } = req.body || {};
    if (admin_presence) {
      await setSetting('admin_presence', String(admin_presence));
    }
    if (currency_rates) {
      await setSetting('currency_rates', JSON.stringify(currency_rates));
    }
    if (fedapay_public !== undefined) {
      await setSetting('fedapay_public', fedapay_public);
    }
    if (fedapay_secret !== undefined) {
      await setSetting('fedapay_secret', fedapay_secret);
    }
    if (fedapay_mode) {
      await setSetting('fedapay_mode', fedapay_mode);
    }
    if (ai_api_key !== undefined) {
      await setSetting('ai_api_key', ai_api_key);
    }
    if (ai_mode) {
      await setSetting('ai_mode', ai_mode);
    }
    if (ai_instructions !== undefined) {
      await setSetting('ai_instructions', ai_instructions);
    }
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

// Public currency rates
router.get('/public/currency', async (req, res, next) => {
  try {
    const rates = await getCurrencyRates();
    res.json({ rates });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

const express = require('express');
const { run, all } = require('../lib/db');
const { requireAdmin, requireAuth } = require('../middleware/auth');

const router = express.Router();

router.post('/quotes', requireAuth, async (req, res, next) => {
  try {
    const { payload, estimateMin, estimateMax } = req.body;
    const clientUserId = req.session?.user?.id || null;
    await run(
      'INSERT INTO quotes (clientUserId, payloadJson, estimateMin, estimateMax, status, createdAt) VALUES (?,?,?,?,?,CURRENT_TIMESTAMP)',
      [clientUserId, JSON.stringify(payload || {}), estimateMin || null, estimateMax || null, 'received']
    );
    res.json({ message: 'Demande de devis enregistrée' });
  } catch (err) {
    next(err);
  }
});

router.get('/admin/quotes', requireAdmin, async (req, res, next) => {
  try {
    const quotes = await all(
      `SELECT q.*, u.firstName, u.lastName, u.email, u.phone
       FROM quotes q
       LEFT JOIN users u ON u.id = q.clientUserId
       ORDER BY q.createdAt DESC`
    );
    res.json({ quotes });
  } catch (err) {
    next(err);
  }
});

router.put('/admin/quotes/:id/status', requireAdmin, async (req, res, next) => {
  try {
    const allowed = ['received', 'in_progress', 'approved', 'rejected'];
    const { status } = req.body || {};
    if (!allowed.includes(status)) return res.status(400).json({ error: 'Statut invalide' });
    await run('UPDATE quotes SET status = ? WHERE id = ?', [status, req.params.id]);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

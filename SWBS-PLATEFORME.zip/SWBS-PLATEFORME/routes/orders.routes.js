const express = require('express');
const { requireAdmin, requireAuth } = require('../middleware/auth');
const { all, get, run } = require('../lib/db');
const { getCurrencyRates, getSetting } = require('../lib/settings');

const ALLOWED_CURRENCIES = ['FCFA', 'NGN', 'USD', 'EUR'];

const router = express.Router();

// Create order (auth required)
router.post('/', requireAuth, async (req, res, next) => {
  try {
    const { items, currency } = req.body || {};
    const rates = await getCurrencyRates();
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Panier vide' });
    }
    const cur = ALLOWED_CURRENCIES.includes(currency) ? currency : 'FCFA';
    const rate = cur === 'FCFA' ? 1 : Number(rates?.[cur] || 0);
    if (cur !== 'FCFA' && (!rate || rate <= 0)) {
      return res.status(400).json({ error: `Taux manquant pour la devise ${cur}` });
    }

    // Fetch products and compute total
    let total = 0;
    const validatedItems = [];
    for (const it of items) {
      const productId = Number(it.productId);
      const qty = Math.max(1, Number(it.quantity || 1));
      const product = await get('SELECT * FROM products WHERE id = ? AND status = ?', [productId, 'published']);
      if (!product) return res.status(400).json({ error: 'Produit introuvable' });
      if (product.stock < qty) return res.status(400).json({ error: `Stock insuffisant pour ${product.title}` });
      const lineTotal = product.price * qty;
      total += lineTotal;
      validatedItems.push({ productId, qty, unitPrice: product.price, total: lineTotal });
    }

    // Convert total to selected currency (base FCFA)
    const totalCurrency = cur === 'FCFA' ? total : Math.round(total * rate);
    const payMode = await getSetting('fedapay_mode', process.env.FEDAPAY_MODE || 'sandbox');
    const reference = `ORD-${Date.now()}-${Math.floor(Math.random() * 100000)}`;

    const orderResult = await run(
      'INSERT INTO orders (clientUserId, total, currency, status, reference, paymentProvider, paymentMode, createdAt, updatedAt) VALUES (?,?,?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)',
      [req.session.user.id, totalCurrency, cur, 'pending', reference, 'fedapay', payMode]
    );
    const orderId = orderResult.lastID || orderResult.insertId;

    for (const it of validatedItems) {
      await run(
        'INSERT INTO order_items (orderId, productId, quantity, unitPrice, total, createdAt) VALUES (?,?,?,?,?,CURRENT_TIMESTAMP)',
        [orderId, it.productId, it.qty, it.unitPrice, it.total]
      );
      await run('UPDATE products SET stock = stock - ? WHERE id = ?', [it.qty, it.productId]);
    }

    res.json({ ok: true, orderId, reference, status: 'pending', total: totalCurrency, currency: cur });
  } catch (err) {
    next(err);
  }
});

// Admin: list orders
router.get('/admin', requireAdmin, async (req, res, next) => {
  try {
    const orders = await all(
      `SELECT o.*, u.firstName, u.lastName, u.email
       FROM orders o
       LEFT JOIN users u ON u.id = o.clientUserId
       ORDER BY o.createdAt DESC`
    );
    res.json({ orders });
  } catch (err) {
    next(err);
  }
});

router.get('/admin/:id/items', requireAdmin, async (req, res, next) => {
  try {
    const items = await all(
      `SELECT oi.*, p.title
       FROM order_items oi
       LEFT JOIN products p ON p.id = oi.productId
       WHERE oi.orderId = ?`,
      [req.params.id]
    );
    res.json({ items });
  } catch (err) {
    next(err);
  }
});

router.put('/admin/:id/status', requireAdmin, async (req, res, next) => {
  try {
    const allowed = ['pending', 'paid', 'canceled', 'delivered'];
    const { status } = req.body || {};
    if (!allowed.includes(status)) return res.status(400).json({ error: 'Statut invalide' });
    await run('UPDATE orders SET status = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?', [status, req.params.id]);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

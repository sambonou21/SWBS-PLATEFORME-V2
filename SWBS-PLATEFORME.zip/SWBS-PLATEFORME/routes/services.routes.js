const express = require('express');
const { all, run } = require('../lib/db');
const { requireAdmin } = require('../middleware/auth');
const { validatePayload } = require('../middleware/validate');

function sanitizeUploadPath(p) {
  if (!p) return '';
  return p.startsWith('/uploads/') ? p : '';
}

const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const services = await all('SELECT * FROM services ORDER BY createdAt DESC');
    res.json({ services });
  } catch (err) {
    next(err);
  }
});

router.post(
  '/',
  requireAdmin,
  validatePayload({
    title: { required: true },
    category: { required: true },
    description: { required: true },
  }),
  async (req, res, next) => {
    try {
      const { title, category, description, icon, imageUrl } = req.body;
      const safeImage = sanitizeUploadPath(imageUrl);
      const result = await run(
        'INSERT INTO services (title, category, description, icon, imageUrl, createdAt, updatedAt) VALUES (?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)',
        [title, category, description, icon || '', safeImage]
      );
      res.json({ id: result.lastID });
    } catch (err) {
      next(err);
    }
  }
);

router.put('/:id', requireAdmin, async (req, res, next) => {
  try {
    const { title, category, description, icon, imageUrl } = req.body;
    const safeImage = sanitizeUploadPath(imageUrl);
    await run(
      'UPDATE services SET title=?, category=?, description=?, icon=?, imageUrl=?, updatedAt=CURRENT_TIMESTAMP WHERE id=?',
      [title, category, description, icon || '', safeImage, req.params.id]
    );
    res.json({ message: 'Service mis à jour' });
  } catch (err) {
    next(err);
  }
});

router.delete('/:id', requireAdmin, async (req, res, next) => {
  try {
    await run('DELETE FROM services WHERE id=?', [req.params.id]);
    res.json({ message: 'Service supprimé' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

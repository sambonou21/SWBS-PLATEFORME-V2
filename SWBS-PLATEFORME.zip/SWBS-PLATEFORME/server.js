require('dotenv').config();
const path = require('path');
const fs = require('fs');
const http = require('http');
const express = require('express');
const session = require('express-session');
const MySQLStore = require('express-mysql-session')(session);
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const compression = require('compression');
const csrf = require('csurf');
const { Server } = require('socket.io');

const { publicDir, uploadDir, rootDir, dbPath } = require('./lib/paths');
const { bootstrap, ensureAdminFromEnv } = require('./lib/db');
const { authLimiter, apiLimiter } = require('./middleware/rateLimit');
const { notFound, errorHandler } = require('./middleware/errors');

// Routes
const authRoutes = require('./routes/auth.routes');
const meRoutes = require('./routes/me.routes');
const servicesRoutes = require('./routes/services.routes');
const portfolioRoutes = require('./routes/portfolio.routes');
const testimonialsRoutes = require('./routes/testimonials.routes');
const chatRoutes = require('./routes/chat.routes');
const uploadsRoutes = require('./routes/uploads.routes');
const quotesRoutes = require('./routes/quotes.routes');
const settingsRoutes = require('./routes/settings.routes');
const productsRoutes = require('./routes/products.routes');
const ordersRoutes = require('./routes/orders.routes');
const paymentsRoutes = require('./routes/payments.routes');

const DIALECT = (process.env.DB_DIALECT || 'sqlite').toLowerCase();

function isAllowedOrigin(origin) {
  // same-origin requests (no Origin header) are allowed
  if (!origin) return true;
  const base = process.env.BASE_URL;
  if (!base) return true; // fallback if not configured
  try {
    const allowed = new URL(base).origin;
    return origin === allowed;
  } catch (e) {
    return false;
  }
}

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: (origin, cb) => cb(null, isAllowedOrigin(origin)), credentials: true },
  transports: ['websocket', 'polling'],
});
app.locals.io = io;

app.disable('x-powered-by');
app.set('trust proxy', 1);

// Logs
const logsDir = path.join(rootDir, 'logs');
if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });
const accessLogStream = fs.createWriteStream(path.join(logsDir, 'access.log'), { flags: 'a' });
app.use(morgan('combined', { stream: accessLogStream }));

app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        "default-src": ["'self'"],
        "base-uri": ["'self'"],
        "object-src": ["'none'"],
        "frame-ancestors": ["'none'"],
        "img-src": ["'self'", "data:", "blob:"],
        "style-src": ["'self'", "'unsafe-inline'"],
        "script-src": ["'self'"],
        "connect-src": ["'self'", "ws:", "wss:"],
        "font-src": ["'self'", "data:"],
        "upgrade-insecure-requests": [],
      },
    },
    crossOriginResourcePolicy: { policy: "same-site" },
  })
);
app.use(compression());
app.use(
  cors({
    origin: (origin, cb) => cb(null, isAllowedOrigin(origin)),
    credentials: true,
  })
);
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// Ensure upload directory exists
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Session store (MySQL in production on o2switch; SQLite fallback for local/dev)
let sessionStore;
if (DIALECT === 'mysql') {
  sessionStore = new MySQLStore({
    host: process.env.MYSQL_HOST || 'localhost',
    port: Number(process.env.MYSQL_PORT || 3306),
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DATABASE,
    // session cleanup
    clearExpired: true,
    checkExpirationInterval: 1000 * 60 * 10,
    expiration: 1000 * 60 * 60 * 24 * 7,
  });
} else {
  // Lazy-require so MySQL deployments don't need this dependency
  const SQLiteStore = require('connect-sqlite3')(session);
  sessionStore = new SQLiteStore({
    db: 'sessions.sqlite',
    dir: path.join(rootDir, 'db'),
  });
}

// Refuse weak secrets in production
if (process.env.NODE_ENV === 'production') {
  const s = process.env.SESSION_SECRET || '';
  if (s.length < 24) {
    throw new Error('SESSION_SECRET is missing/too short. Set a long random secret in production.');
  }
}

const sessionMiddleware = session({
  store: sessionStore,
  secret: process.env.SESSION_SECRET || 'dev-secret-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 1000 * 60 * 60 * 24 * 7,
  },
});

app.use(sessionMiddleware);


// CSRF protection (session-based). Only skip explicit webhook endpoints.
const csrfProtection = csrf();
app.use((req, res, next) => {
  const p = req.path || '';
  if (p.startsWith('/api/webhook')) return next();
  return csrfProtection(req, res, next);
});

// Provide CSRF token for fetch() calls (session-backed)
app.get('/api/csrf', (req, res) => {
  res.json({ csrfToken: req.csrfToken() });
});

// Pretty URLs (no .html in the browser bar)
const pageMap = {
  '/': 'index.html',
  '/services': 'services.html',
  '/tarifs': 'tarifs.html',
  '/a-propos': 'a-propos.html',
  '/portfolio': 'portfolio.html',
  '/contact': 'contact.html',
  '/devis': 'devis.html',
  '/login': 'login.html',
  '/register': 'register.html',
  '/chat': 'chat.html',
  '/verify-email': 'verify-email.html',
  '/dashboard': 'dashboard.html',
  '/boutique': 'boutique.html',
};

// Admin pretty URLs (no .html)
const adminPageMap = {
  '/admin/login': 'admin/admin-login.html',
  '/admin/dashboard': 'admin/dashboard.html',
  '/admin/clients': 'admin/clients.html',
  '/admin/chat': 'admin/chat.html',
  '/admin/services': 'admin/services.html',
  '/admin/portfolio': 'admin/portfolio.html',
  '/admin/quotes': 'admin/quotes.html',
  '/admin/avis': 'admin/avis.html',
  '/admin/settings': 'admin/settings.html',
  '/admin/products': 'admin/products.html',
  '/admin/orders': 'admin/orders.html',
};

app.get(Object.keys(adminPageMap), (req, res) => {
  res.sendFile(adminPageMap[req.path], { root: publicDir });
});

app.get('/admin/*.html', (req, res, next) => {
  const p = req.path; // e.g. /admin/dashboard.html
  const noExt = p.replace(/\.html$/, '');
  if (Object.prototype.hasOwnProperty.call(adminPageMap, noExt)) {
    const qs = req.originalUrl.includes('?') ? req.originalUrl.substring(req.originalUrl.indexOf('?')) : '';
    return res.redirect(301, `${noExt}${qs}`);
  }
  return next();
});

app.get(Object.keys(pageMap), (req, res) => {
  res.sendFile(pageMap[req.path], { root: publicDir });
});

// Boutique product detail (pretty URL)
app.get('/boutique/:slug', (req, res) => {
  res.sendFile('produit.html', { root: publicDir });
});

// Redirect legacy .html URLs to pretty paths
app.get('/*.html', (req, res, next) => {
  const p = req.path;
  const noExt = p.replace(/\.html$/, '');
  // keep index.html -> /
  if (p === '/index.html') return res.redirect(301, '/');
  // Only redirect if it is one of our known pages
  if (Object.prototype.hasOwnProperty.call(pageMap, noExt)) {
    const qs = req.originalUrl.includes('?') ? req.originalUrl.substring(req.originalUrl.indexOf('?')) : '';
    return res.redirect(301, `${noExt}${qs}`);
  }
  return next();
});

// Static files
app.use('/uploads', express.static(uploadDir));
app.use(express.static(publicDir));

// Rate limiting for auth endpoints
app.use('/api/auth', authLimiter);
app.use('/api', apiLimiter);

// API routes
app.use('/api/auth', authRoutes);
app.use('/api', meRoutes);
app.use('/api/services', servicesRoutes);
app.use('/api/portfolio', portfolioRoutes);
app.use('/api/testimonials', testimonialsRoutes);
app.use('/api', chatRoutes);
app.use('/api/uploads', uploadsRoutes);
app.use('/api', quotesRoutes);
app.use('/api', settingsRoutes);
app.use('/api/products', productsRoutes);
app.use('/api/orders', ordersRoutes);
app.use('/api', paymentsRoutes);

app.use(notFound);
app.use(errorHandler);

// Socket.io with shared sessions
io.use((socket, next) => {
  sessionMiddleware(socket.request, {}, next);
});

require('./sockets/chat.socket')(io);

async function start() {
  if (process.env.NODE_ENV === 'production') {
    if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 24) {
      throw new Error('SESSION_SECRET est obligatoire (>=24 caractères) en production');
    }
  }
  await bootstrap();
  await ensureAdminFromEnv();

  const PORT = process.env.PORT || 3000;
  server.listen(PORT, () => {
    console.log(`SWBS Platform prête sur le port ${PORT}`);
    console.log(`DB: ${dbPath}`);
  });
}

start().catch((err) => {
  console.error('Impossible de démarrer le serveur', err);
  process.exit(1);
});

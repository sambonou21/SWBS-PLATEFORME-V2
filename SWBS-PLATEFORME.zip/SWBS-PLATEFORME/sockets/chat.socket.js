const { get, run, all } = require('../lib/db');
const { getSetting } = require('../lib/settings');

module.exports = function chatSocket(io) {
  const adminSockets = new Set();

  const broadcastAdminPresence = () => {
    const online = adminSockets.size > 0;
    io.emit('admin:online', { online });
  };

  async function aiShouldReply() {
    const mode = (await getSetting('ai_mode', process.env.AI_MODE || 'off')) || 'off';
    if (mode !== 'on') return false;
    const presence = await getSetting('admin_presence', 'present');
    if (presence === 'present' && adminSockets.size > 0) return false;
    const key = await getSetting('ai_api_key', process.env.AI_API_KEY || '');
    if (!key) return false;
    return true;
  }

  async function aiReply(conversationId) {
    try {
      if (!(await aiShouldReply())) return;
      const key = await getSetting('ai_api_key', process.env.AI_API_KEY || '');
      const instructions = (await getSetting('ai_instructions', process.env.AI_INSTRUCTIONS || '')) || '';
      const baseRules =
        instructions ||
        'Tu es l assistant SWBS. Tu aides uniquement sur SWBS (services, support, boutique, devis, portfolio). Demande les besoins, propose un devis ou un rendez-vous. Pas de sujets hors SWBS.';
      const safety = 'Si le sujet est hors SWBS, indique poliment que tu ne traites que SWBS.';
      const history = await all(
        'SELECT senderRole, body FROM messages WHERE conversationId = ? ORDER BY createdAt ASC',
        [conversationId]
      );
      const prompt = [
        { role: 'system', content: `${baseRules} ${safety}` },
        ...history.map((m) => ({
          role: m.senderRole === 'admin' || m.senderRole === 'ai' ? 'assistant' : 'user',
          content: m.body,
        })),
      ];
      const model = process.env.AI_MODEL || 'gpt-3.5-turbo';
      const resp = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${key}`,
        },
        body: JSON.stringify({
          model,
          messages: prompt,
          max_tokens: 200,
          temperature: 0.6,
        }),
      });
      const data = await resp.json().catch(() => null);
      if (!resp.ok || !data) return;
      const aiText = data.choices?.[0]?.message?.content?.trim();
      if (!aiText) return;
      const saved = await run(
        'INSERT INTO messages (conversationId, senderRole, senderUserId, body, createdAt, isRead) VALUES (?,?,?,?,CURRENT_TIMESTAMP,0)',
        [conversationId, 'ai', null, aiText]
      );
      await run('UPDATE conversations SET updatedAt = CURRENT_TIMESTAMP WHERE id = ?', [conversationId]);
      const message = await get('SELECT * FROM messages WHERE id = ?', [saved.lastID]);
      io.to('admins').emit('chat:notify', { conversationId });
      io.to(String(conversationId)).emit('chat:message', { message });
    } catch (err) {
      console.error('AI reply failed', err);
    }
  }

  io.on('connection', (socket) => {
    const session = socket.request.session;
    const user = session?.user;
    const guest = session?.guest;
    if (!user && !guest) {
      socket.disconnect();
      return;
    }

    const actor = user || { role: 'guest', id: null, firstName: guest?.name || 'Invite', email: guest?.email };

    if (actor.role === 'admin') {
      adminSockets.add(socket.id);
      socket.join('admins');
      broadcastAdminPresence();
    } else {
      socket.emit('admin:online', { online: adminSockets.size > 0 });
    }

    socket.on('chat:join', async ({ conversationId }) => {
      if (!conversationId) return;
      const convo = await get('SELECT * FROM conversations WHERE id = ?', [conversationId]);
      if (!convo) return;
      if (actor.role === 'client' && convo.clientUserId !== actor.id) return;
      if (actor.role === 'guest' && String(guest?.conversationId) !== String(conversationId)) return;
      socket.join(String(conversationId));
    });

    socket.on('chat:typing', ({ conversationId, isTyping }) => {
      if (!conversationId) return;
      socket.to(String(conversationId)).emit('chat:typing', { conversationId, from: actor.role, isTyping: !!isTyping });
    });

    socket.on('chat:message', async ({ conversationId, body }, cb) => {
      if (!conversationId || !body) return;
      const convo = await get('SELECT * FROM conversations WHERE id = ?', [conversationId]);
      if (!convo) return;
      if (actor.role === 'client' && convo.clientUserId !== actor.id) return;
      if (actor.role === 'guest' && String(guest?.conversationId) !== String(conversationId)) return;
      const saved = await run(
        'INSERT INTO messages (conversationId, senderRole, senderUserId, body, createdAt, isRead) VALUES (?,?,?,?,CURRENT_TIMESTAMP,0)',
        [conversationId, actor.role, actor.id, body]
      );
      await run('UPDATE conversations SET updatedAt = CURRENT_TIMESTAMP WHERE id = ?', [conversationId]);
      const message = await get('SELECT * FROM messages WHERE id = ?', [saved.lastID]);
      io.to('admins').emit('chat:notify', { conversationId });
      io.to(String(conversationId)).emit('chat:message', { message });
      if (typeof cb === 'function') cb({ ok: true, message });
      if (actor.role !== 'admin') {
        aiReply(conversationId);
      }
    });

    socket.on('chat:read', async ({ conversationId }) => {
      if (!conversationId) return;
      const convo = await get('SELECT * FROM conversations WHERE id = ?', [conversationId]);
      if (!convo) return;
      if (actor.role === 'client' && convo.clientUserId !== actor.id) return;
      if (actor.role === 'guest' && String(guest?.conversationId) !== String(conversationId)) return;
      await run(
        'UPDATE messages SET isRead = 1 WHERE conversationId = ? AND senderRole != ?',
        [conversationId, actor.role]
      );
      io.to(String(conversationId)).emit('chat:read', { conversationId, by: actor.role });
    });

    socket.on('disconnect', () => {
      if (actor.role === 'admin') {
        adminSockets.delete(socket.id);
        broadcastAdminPresence();
      }
    });
  });
};

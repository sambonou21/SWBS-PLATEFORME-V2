# SWBS Platform

Plateforme multi-pages + admin + chat temps reel pour **Sam Web Business Services (SWBS)**, basee a Porto-Novo (Benin). Stack : Node.js/Express, SQLite ou MySQL, Socket.IO, sessions securisees, frontend HTML/CSS/JS.

## Installation locale
1) `npm install`  
2) Copier `.env.example` en `.env` et ajuster les valeurs.  
3) Initialiser la base si besoin : `npm run init-db` (ou laisser le serveur creer/peupler au premier demarrage).  
4) Demarrage :  
   - Production : `npm start`  
   - Dev (reload) : `npm run dev`

## Configuration `.env` (o2switch / local)
```
PORT=3000
SESSION_SECRET=change-me-strong
DB_PATH=/home/USER/swbs-platform/db/database.sqlite
UPLOAD_DIR=/home/USER/swbs-platform/uploads
BASE_URL=https://votre-domaine
ADMIN_EMAIL=admin@swbs.bj
ADMIN_PASSWORD=ChangeMoi2025!
```

## Commandes npm
- `npm start` : lance `server.js`
- `npm run dev` : lance avec `nodemon`
- `npm run init-db` : execute `db/init.sql` pour creer et peupler la base

## Deploiement o2switch (cPanel > Setup Node.js App / Passenger)
- **Application root** : `swbs-platform` (chemin ou se trouve `server.js`)
- **Application URL** : votre domaine ou sous-domaine
- **Startup file** : `server.js`
- **Node version** : >= 18
- Variables d'environnement : selon `.env.example` (PORT laisse vide ou 3000, DB_PATH/UPLOAD_DIR vers vos chemins absolus).  
- **Uploads** : le dossier defini par `UPLOAD_DIR` est servi statiquement via `/uploads`.
- **Socket.IO** : configure avec `transports: ["websocket","polling"]` pour compatibilite Passenger.
- Ne pas placer les sources dans `public_html`; Express sert `/public` et `/uploads`.

## Admin
- Un admin est cree au premier run si `ADMIN_EMAIL`/`ADMIN_PASSWORD` sont definis dans `.env`.
- Connexion : `/admin/login`
- Redirection apres login : `/admin/dashboard`

## Structure
Arborescence principale : `server.js`, `db/` (init + migrations), `lib/`, `middleware/`, `routes/`, `sockets/`, `public/` (pages publiques + admin), `uploads/` (stockage des images).

## Securite (production)
- CSRF actif sur les endpoints sensibles (admin CRUD, uploads, etc.). Recuperation du token via `GET /api/csrf`.
- CSP (Helmet) active (scripts `self`, connexions `self` + ws/wss pour Socket.IO).
- Sessions persistantes en SQLite (connect-sqlite3) ou MySQL (express-mysql-session) et cookies securises en production.

## Deploiement o2switch (exemple)
Chemin racine (Application root): `/home/sc4assa9716/swbs.site`
- DB_PATH: `/home/sc4assa9716/swbs.site/db/database.sqlite`
- UPLOAD_DIR: `/home/sc4assa9716/swbs.site/uploads`

## Deploiement o2switch (MySQL)
- Placer le projet dans `/home/sc4assa9716/swbs.site` (hors `public_html`).
- Dans cPanel > Setup Node.js App:
  - Application root: `swbs.site`
  - Startup file: `server.js`
  - Node >= 18
  - Mode: Production
- Installer les dependances: `npm install`
- Initialiser la base: `npm run init-db`

### .env (production)
- Adapter :
  - `BASE_URL`
  - `SESSION_SECRET`
  - `ADMIN_EMAIL` / `ADMIN_PASSWORD`
  - Variables MySQL si besoin

### Notes Socket.IO
- Le projet supporte `websocket` + `polling` (fallback) pour compat Passenger.

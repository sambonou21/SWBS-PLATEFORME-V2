function notFound(req, res) {
  res.status(404).json({ error: 'Route introuvable' });
}

function errorHandler(err, req, res, next) {
  if (err.code === 'EBADCSRFTOKEN') {
    return res.status(403).json({ error: 'CSRF token invalide ou manquant' });
  }
  console.error('Erreur serveur:', err);
  const status = err.status || 500;
  res.status(status).json({ error: err.message || 'Erreur interne' });
}

module.exports = {
  notFound,
  errorHandler,
};

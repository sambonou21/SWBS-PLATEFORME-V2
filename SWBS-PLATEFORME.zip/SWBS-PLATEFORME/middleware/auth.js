function requireAuth(req, res, next) {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ error: 'Non autorisé' });
  }
  if (req.session.user.isActive === 0) {
    return res.status(403).json({ error: 'Compte désactivé' });
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session || !req.session.user || req.session.user.role !== 'admin') {
    return res.status(403).json({ error: 'Accès administrateur requis' });
  }
  next();
}

module.exports = {
  requireAuth,
  requireAdmin,
};

const emailRegex = /^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i;
const phoneRegex = /^[0-9+()\s-]{6,}$/;

function validatePayload(schema) {
  return (req, res, next) => {
    const errors = [];
    Object.entries(schema).forEach(([field, rules]) => {
      const value = rules.source === 'query' ? req.query[field] : req.body[field];
      if (rules.required && (value === undefined || value === null || String(value).trim() === '')) {
        errors.push(`${field} est requis`);
        return;
      }
      if (!value) return;
      if (rules.type === 'email' && !emailRegex.test(String(value))) {
        errors.push(`${field} invalide`);
      }
      if (rules.type === 'phone' && !phoneRegex.test(String(value))) {
        errors.push(`${field} invalide`);
      }
      if (rules.minLength && String(value).length < rules.minLength) {
        errors.push(`${field} doit contenir au moins ${rules.minLength} caracteres`);
      }
    });

    if (errors.length) {
      return res.status(400).json({ errors });
    }
    next();
  };
}

module.exports = {
  validatePayload,
};

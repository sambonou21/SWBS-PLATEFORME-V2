# Déploiement sur o2switch (CloudLinux NodeJS Selector + MySQL)

Ce projet est prêt pour un hébergement o2switch avec **NodeJS Selector (Passenger)** et **MySQL/MariaDB**.

## 1) Préparer le dossier

1. Uploadez le projet dans :
   - exemple : `/home/<user>/swbs.site/`
2. **Important (CloudLinux)** :
   - Le dossier **`node_modules/` ne doit pas être présent dans le ZIP**.
   - NodeJS Selector installe les dépendances dans un *virtual env* et crée un **symlink** `node_modules`.

## 2) Créer l’application NodeJS (cPanel → NodeJS Selector)

Dans **NodeJS Selector** :
- **Node version** : 18 (ou 20 si disponible)
- **Application root** : le dossier de l’app (ex: `/home/<user>/swbs.site`)
- **Application URL** : votre domaine/sous-domaine
- **Application startup file** : `server.js`

Cliquez **Create** puis **Start/Restart**.

## 3) Variables d’environnement (.env)

Copiez `.env.example` vers `.env` puis ajustez au minimum :

- `NODE_ENV=production`
- `BASE_URL=https://votre-domaine.tld`
- `APP_BASE_URL=https://votre-domaine.tld`
- `SESSION_SECRET=<chaine-longue>` (32+ caractères)

### MySQL
- `DB_DIALECT=mysql`
- `MYSQL_HOST=localhost`
- `MYSQL_PORT=3306`
- `MYSQL_DATABASE=...`
- `MYSQL_USER=...`
- `MYSQL_PASSWORD=...`

### Uploads
Par défaut : `public/uploads`.
Vous pouvez forcer :
- `UPLOAD_DIR=/home/<user>/swbs.site/public/uploads`

Assurez-vous que le dossier existe et est writable :

```bash
mkdir -p public/uploads/services public/uploads/portfolio public/uploads/products
chmod -R 775 public/uploads
```

## 4) Installer les dépendances (via NodeJS Selector)

Dans l’interface NodeJS Selector, utilisez l’action **Run NPM Install**.

> Si vous installez en SSH, faites-le **dans l’environnement nodevenv** du Selector.

## 5) Initialiser la base (migrations)

Toujours dans l’environnement Node :

```bash
cd /home/<user>/swbs.site
npm run init-db
```

Le système applique :
- init MySQL si tables absentes
- migrations **MySQL uniquement** (les migrations SQLite sont ignorées automatiquement)

## 6) Redémarrer Passenger

Après une mise à jour :

```bash
cd /home/<user>/swbs.site
mkdir -p tmp && touch tmp/restart.txt
```

## 7) Vérifications rapides

- Public : `/` , `/services`, `/portfolio`, `/devis`, `/chat`, `/boutique`
- Admin : `/admin/login` puis `/admin/dashboard`
- Upload : ajouter un service/produit avec image (upload obligatoire)

## 8) Logs en cas de 500

Cherchez les logs dans `logs/` et/ou logs Passenger :

```bash
tail -n 150 logs/access.log 2>/dev/null
find . -maxdepth 2 -type f -name "*error*log" -o -name "passenger*" 
```
